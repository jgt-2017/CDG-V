const THEME = {
  title: "CDG Tracking",
  description: "Matrix CDG Tracking",
};

export { THEME };
