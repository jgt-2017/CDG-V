import TablePage from "./TablePage";

export default function TableContainer() {
  return (
    <>
      return <TablePage />;
    </>
  );
}
