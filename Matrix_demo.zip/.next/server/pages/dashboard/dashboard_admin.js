(function() {
var exports = {};
exports.id = "pages/dashboard/dashboard_admin";
exports.ids = ["pages/dashboard/dashboard_admin"];
exports.modules = {

/***/ "./components/cards/ProjectHorizontal.jsx":
/*!************************************************!*\
  !*** ./components/cards/ProjectHorizontal.jsx ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ ProjectsHorizontal; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\components\\cards\\ProjectHorizontal.jsx";



function ProjectsHorizontal() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "d-flex p-3 align-items-center text-grey-50 bg-white box-shadow",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "col-sm-3",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("blockquote", {
          className: "blockquote text-left p-0 m-0",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
            href: "#",
            title: "Project Image",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
              className: "mr-3 img-thumbnail",
              src: "/MAT.jpg",
              alt: "Profile Image"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 34,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "col-sm-9",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Card, {
          className: "h-100 mb-0",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.CardBody, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.CardTitle, {
              tag: "h4",
              className: "headline-mm",
              children: "Matrix-System 1A"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
              hover: true,
              size: "md",
              borderless: true,
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tbody", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                    scope: "row",
                    children: "1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 60,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "System Location"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 61,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "586 Gulf Avenue, Staten Island, New York"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 62,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                    scope: "row",
                    children: "2"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 65,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "System Size"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 66,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "3,246 kW"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 67,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 64,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                    scope: "row",
                    children: "3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 70,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "Utility"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 71,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "ConEdison"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 72,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 69,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                    scope: "row",
                    children: "4"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 75,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "Subscription Status"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 76,
                    columnNumber: 21
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                    children: "100%"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 77,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 74,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 58,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 29,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/container/charts/barChart.js":
/*!*************************************************!*\
  !*** ./components/container/charts/barChart.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ BarChart; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-chartjs-2 */ "react-chartjs-2");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\components\\container\\charts\\barChart.js";


function BarChart() {
  const state = {
    labels: ["January", "February", "March", "April", "May"],
    datasets: [{
      label: "System Production (kWh)",
      backgroundColor: "rgb(70,130,180)",
      borderColor: "rgba(0,0,0,0)",
      borderWidth: 2,
      data: [65, 59, 80, 81, 56]
    }]
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__.Bar, {
      data: state,
      options: {
        title: {
          display: true,
          text: "Average Rainfall per month",
          fontSize: 20
        },
        legend: {
          display: true,
          position: "right"
        }
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/container/dashboard/DashboardContainer.jsx":
/*!***************************************************************!*\
  !*** ./components/container/dashboard/DashboardContainer.jsx ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ DashboardContainer; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _DashboardPage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DashboardPage */ "./components/container/dashboard/DashboardPage.jsx");


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\components\\container\\dashboard\\DashboardContainer.jsx";

function DashboardContainer() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_DashboardPage__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

/***/ }),

/***/ "./components/container/dashboard/DashboardPage.jsx":
/*!**********************************************************!*\
  !*** ./components/container/dashboard/DashboardPage.jsx ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ DashboardPage; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _charts_barChart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../charts/barChart */ "./components/container/charts/barChart.js");
/* harmony import */ var _components_table_TableContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/table/TableContainer */ "./components/table/TableContainer.jsx");
/* harmony import */ var _components_cards_ProjectHorizontal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/cards/ProjectHorizontal */ "./components/cards/ProjectHorizontal.jsx");


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\components\\container\\dashboard\\DashboardPage.jsx";
//import React, { memo } from 'react';

 //import ProjectCard from "../card/projects";



function DashboardPage() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
      children: " Solar Admin Dashboard"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "d-flex p-3 my-3 align-items-center text-white-50 bg-gradient-primary box-shadow",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
        className: "mr-3",
        src: "/MS.png",
        alt: "Brand",
        width: "48",
        height: "48"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "lh-100",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h6", {
          className: "mb-0 text-white lh-100",
          children: "Community Solar CDG"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("small", {
          children: "MaxSolar"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "ml-auto",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("blockquote", {
          className: "blockquote text-right p-0 m-0",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
            className: "m-0",
            children: "Welcome to the CDG Admin Dashboard"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Row, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
        md: "6",
        lg: "4",
        className: "mb-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Card, {
          className: "h-100 mb-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardBody, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardTitle, {
              tag: "h4",
              className: "headline-mm",
              children: "Portfolio Summary"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 52,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Row, {
              className: "mb-2",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
                xs: "4",
                className: "d-inline align-items-center text-success",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                  className: "fas fa-users fa-3x"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 61,
                  columnNumber: 19
                }, this), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                  children: ["25 ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardText, {
                    children: "Subscribers"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 63,
                    columnNumber: 24
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
                xs: "4",
                className: "d-inline align-items-center text-info",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                  className: "fas fa-solar-panel fa-3x"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 67,
                  columnNumber: 19
                }, this), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                  children: ["10 ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardText, {
                    children: "Projects"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 69,
                    columnNumber: 24
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 68,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 66,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
                xs: "4",
                className: "d-inline align-items-center text-primary",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                  className: "fas fas fa-coins fa-3x"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 76,
                  columnNumber: 19
                }, this), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                  children: ["$ 75K ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardText, {
                    children: "Revenue"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 78,
                    columnNumber: 27
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 77,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 56,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Button, {
              color: "danger",
              size: "md",
              block: true,
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                className: "fas fa-chart-bar"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 17
              }, this), " statistic"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 84,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 51,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
        md: "6",
        lg: "4",
        className: "mb-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Card, {
          className: "h-100 mb-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardBody, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardTitle, {
              tag: "h4",
              className: "headline-mm",
              children: "System Production - 2021 (YTD)"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 94,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Row, {
              className: "mb-2",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
                xs: "",
                className: "d-inline align-items-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_charts_barChart__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 100,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 99,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 98,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 91,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
        md: "6",
        lg: "4",
        className: "mb-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Card, {
          className: "h-100 mb-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardBody, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardTitle, {
              tag: "h4",
              className: "headline-mm",
              children: "Project Portfolio"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 167,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Row, {
              className: "mb-2",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
                xs: "",
                className: "d-inline align-items-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_table_TableContainer__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 172,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 166,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 165,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 164,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
        md: "12",
        lg: "12",
        className: "mb-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Card, {
          className: "h-100 mb-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardBody, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardTitle, {
              tag: "h4",
              className: "headline-mm",
              children: "Recent Additions"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 293,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_cards_ProjectHorizontal__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 298,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 292,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 291,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 290,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./components/table/TableContainer.jsx":
/*!*********************************************!*\
  !*** ./components/table/TableContainer.jsx ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ TableContainer; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _TablePage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TablePage */ "./components/table/TablePage.jsx");


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\components\\table\\TableContainer.jsx";

function TableContainer() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: ["return ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_TablePage__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 14
    }, this), ";"]
  }, void 0, true);
}

/***/ }),

/***/ "./components/table/TablePage.jsx":
/*!****************************************!*\
  !*** ./components/table/TablePage.jsx ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ TablePage; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\components\\table\\TablePage.jsx";

function TablePage() {
  //const { dispatch, storeLayout } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "hero",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Row, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Col, {
          xs: "12",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 77,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Table, {
            striped: true,
            hover: true,
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("thead", {
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  children: "#"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  children: "Project Name"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 82,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  children: "System Size"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  children: "Utility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 84,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tbody", {
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  scope: "row",
                  children: "1"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 89,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "Matrix-System 1A"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 90,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "2400 kW (dc)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 91,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "ConEd"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 92,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 88,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  scope: "row",
                  children: "2"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 95,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "Matrix-System 1B"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 96,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "5141 kW (dc)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 97,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "ConEd"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 98,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 94,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("th", {
                  scope: "row",
                  children: "3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 101,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "Matrix - System 2A"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 102,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "2808 kW (dc)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("td", {
                  children: "ConEd"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 104,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 100,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 87,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./constants/menus.jsx":
/*!*****************************!*\
  !*** ./constants/menus.jsx ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MENUS": function() { return /* binding */ MENUS; },
/* harmony export */   "SUBMENUS": function() { return /* binding */ SUBMENUS; }
/* harmony export */ });
// Menus
const MENUS = [{
  name: "",
  as: "a",
  href: "/dashboard/dashboard",
  label: "Dashboard",
  icon: "fas fa-chart-pie"
}, {
  name: "Projects",
  as: "a",
  href: "/card/posts",
  label: "Projects",
  icon: "fas fa-clone"
}, {
  name: "Subscribers",
  as: "a",
  href: "/form/buttons",
  label: "Subscribers",
  icon: "fas fa-bullseye"
} // {
//   name: 'tables',
//   as: 'a',
//   href: '/table/tables',
//   label: 'Tables',
//   icon: 'fas fa-columns',
// },
// {
//   name: 'typography',
//   as: 'a',
//   href: '/page/typography',
//   label: 'Typography',
//   icon: 'fas fa-list-ul',
// },
]; // Sub menus

const SUBMENUS = [{
  name: "Account",
  as: "a",
  href: "/card/employees",
  label: "Account",
  icon: "" // },
  // {
  //   name: 'carousels',
  //   as: 'a',
  //   href: '/carousel/carousels',
  //   label: 'Carousels',
  //   icon: '',
  // },
  // {
  //   name: 'pages',
  //   as: 'a',
  //   href: '#',
  //   label: 'Pages',
  //   icon: '',
  //   subLinks: [
  //     {
  //       name: 'profile',
  //       as: 'a',
  //       href: '/page/profile',
  //       label: 'Profile',
  //       icon: '',
  //     },
  //     {
  //       name: 'setting',
  //       as: 'a',
  //       href: '/page/setting',
  //       label: 'Settings',
  //       icon: '',
  //     },
  //     {
  //       name: 'login',
  //       as: 'a',
  //       href: '/page/login',
  //       label: 'Login',
  //       icon: '',
  //     },
  //   ],
  // },
  // {
  //   name: 'forms',
  //   as: 'a',
  //   href: '/form/forms',
  //   label: 'Forms',
  //   icon: '',
  // },
  // {
  //   name: 'pages',
  //   as: 'a',
  //   href: '#',
  //   label: 'Pages',
  //   icon: '',
  //   subLinks: [
  //     {
  //       name: 'profile',
  //       as: 'a',
  //       href: '/page/profile',
  //       label: 'Profile',
  //       icon: '',
  //     },
  //     {
  //       name: 'setting',
  //       as: 'a',
  //       href: '/page/setting',
  //       label: 'Settings',
  //       icon: '',
  //     },
  //     {
  //       name: 'login',
  //       as: 'a',
  //       href: '/page/login',
  //       label: 'Login',
  //       icon: '',
  //     },
  //   ],

}];


/***/ }),

/***/ "./constants/vars.jsx":
/*!****************************!*\
  !*** ./constants/vars.jsx ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "THEME": function() { return /* binding */ THEME; }
/* harmony export */ });
const THEME = {
  title: "CDG Tracking",
  description: "Matrix CDG Tracking"
};


/***/ }),

/***/ "./layout/MainLayout.jsx":
/*!*******************************!*\
  !*** ./layout/MainLayout.jsx ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ MainLayout; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _nav_NavLeft__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./nav/NavLeft */ "./layout/nav/NavLeft.jsx");
/* harmony import */ var _nav_NavBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./nav/NavBar */ "./layout/nav/NavBar.jsx");


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\layout\\MainLayout.jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function MainLayout(mainProps) {
  const {
    children,
    dispatch,
    storeLayout,
    activeLink
  } = mainProps;
  /* layout vars */

  const wideNav = {
    width: "240px"
  };
  const wideContent = {
    marginLeft: "240px"
  };
  const {
    0: isOpen,
    1: setIsOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: isToggled,
    1: setIsToggled
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: isWideNav,
    1: setIsWideNav
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_objectSpread({}, wideNav));
  const {
    0: isWideContent,
    1: setIsWideContent
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_objectSpread({}, wideContent));

  const toggle = () => setIsOpen(!isOpen);

  const toggleLeft = () => {
    setIsToggled(!isToggled);

    if (storeLayout.toggle) {
      setIsWideNav(_objectSpread({}, wideNav));
      setIsWideContent(_objectSpread({}, wideContent));
    } else {
      setIsWideNav({
        width: 0,
        padding: 0
      });
      setIsWideContent({
        marginLeft: 0
      });
    }

    dispatch({
      type: ACTION_TYPES.LAYOUT.TOGGLE,
      toggle: isToggled
    });
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_nav_NavBar__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_3__.Container, {
      fluid: true,
      className: "wrapper",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {
          className: "wrapper-left",
          style: isWideNav,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_nav_NavLeft__WEBPACK_IMPORTED_MODULE_4__.default, {
            activeLink: activeLink
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {
          className: "wrapper-content",
          style: isWideContent,
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./layout/head/HeadDefault.jsx":
/*!*************************************!*\
  !*** ./layout/head/HeadDefault.jsx ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ HeadDefault; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants_vars__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../constants/vars */ "./constants/vars.jsx");

var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\layout\\head\\HeadDefault.jsx";




function HeadDefault({
  title,
  description,
  keyword,
  ogTitle,
  ogDescription,
  ogImageUrl,
  ogImageAlt,
  ogUrl
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
      children: [title, " | ", _constants_vars__WEBPACK_IMPORTED_MODULE_4__.THEME.title]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
      rel: "icon",
      href: "/favicon.ico"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      name: "title",
      content: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      name: "description",
      content: description
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      name: "keywords",
      content: keyword
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:title",
      content: ogTitle
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:description",
      content: ogDescription
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:url",
      content: ogUrl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:image",
      content: ogImageUrl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:image:url",
      content: ogImageUrl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:image:alt",
      content: ogImageAlt
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:image:type",
      content: "image/jpg"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:image:width",
      content: "1200"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
      property: "og:image:height",
      content: "628"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./layout/nav/NavBar.jsx":
/*!*******************************!*\
  !*** ./layout/nav/NavBar.jsx ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ NavBar; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\layout\\nav\\NavBar.jsx";


function NavBar({
  /* state vars */
  isOpen,
  isToggled,

  /* toggles */
  toggle,
  toggleLeft
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "container",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Navbar, {
      color: "bg-info",
      dark: true,
      expand: "sm",
      fixed: "top",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavbarBrand, {
        href: "/",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
          src: "/MM.svg",
          alt: "Logo",
          className: "",
          height: "80",
          width: "100"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavbarToggler, {
        onClick: toggle,
        color: "dark"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Collapse, {
        isOpen: isOpen,
        navbar: true,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Nav, {
          className: "mr-auto",
          navbar: true,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.UncontrolledDropdown, {
            nav: true,
            inNavbar: true,
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownToggle, {
              nav: true,
              caret: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 51,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownMenu, {
              right: true,
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownItem, {
                tag: "div",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                  href: "/card/posts",
                  className: "text-primary",
                  children: "Cards"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 54,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 53,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownItem, {
                tag: "div",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                  href: "/table/tables",
                  className: "text-primary",
                  children: "Tables"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 58,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownItem, {
                tag: "div",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                  href: "/form/buttons",
                  className: "text-primary",
                  children: "Buttons"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 64,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 63,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownItem, {
                tag: "div",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                  href: "/form/forms",
                  className: "text-primary",
                  children: "Forms"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 70,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 69,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 52,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavbarText, {
          className: "align-self-center text-left font-weight-bold",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            src: "/images/profile2.jpg",
            className: "border rounded-circle img-42 img-fluid mr-1"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, this), "Logout"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./layout/nav/NavLeft.jsx":
/*!********************************!*\
  !*** ./layout/nav/NavLeft.jsx ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ NavLeft; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_menus__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../constants/menus */ "./constants/menus.jsx");


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\layout\\nav\\NavLeft.jsx";


function NavLeft(props) {
  const {
    activeLink
  } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      className: "headline",
      children: "Dashboard"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: true,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.ListGroup, {
        flush: true,
        className: "list-group-nav-left",
        tag: "div",
        children: _constants_menus__WEBPACK_IMPORTED_MODULE_2__.MENUS.map((item, k) => {
          const isActive = activeLink === item.name ? true : false;
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.ListGroupItem, {
            active: isActive,
            tag: item.as,
            href: "#",
            children: [item.icon && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
              className: item.icon
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 28,
              columnNumber: 31
            }, this), " ", item.label]
          }, `l${k}`, true, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 15
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      className: "headline",
      children: "Settings"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.ListGroup, {
        flush: true,
        className: "list-group-nav-left",
        tag: "div",
        children: _constants_menus__WEBPACK_IMPORTED_MODULE_2__.SUBMENUS.map((subItem, k) => {
          const isActive = activeLink === subItem.name ? true : false;
          const activeMenus = activeLink && activeLink.split(".");
          return !subItem.subLinks && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.ListGroupItem, {
            active: isActive,
            tag: subItem.as,
            href: "#",
            children: [subItem.icon && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
              className: subItem.icon
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 36
            }, this), "\xA0", subItem.label]
          }, `k${k}`, true, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 17
          }, this) || /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.ListGroupItem, {
            tag: "div"
            /* active={activeMenus[0] ? true : false} */
            ,
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              href: subItem.href,
              className: "dropdown-toggle",
              id: `toggleCollapser-${k}`,
              children: [subItem.icon && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                className: subItem.icon
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 62,
                columnNumber: 38
              }, this), "\xA0", subItem.label]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 57,
              columnNumber: 19
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.UncontrolledCollapse, {
              toggler: `toggleCollapser-${k}` // isOpen={activeMenus[1] ? true : false}
              ,
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Nav, {
                vertical: true,
                className: "mt-2",
                children: subItem.subLinks.map((subs, l) => {
                  const isSubActive = activeMenus && activeMenus[1] === subs.name ? true : false;
                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
                    active: isSubActive === true,
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
                      href: subs.href,
                      children: subs.label
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 78,
                      columnNumber: 29
                    }, this)
                  }, `l${l}`, false, {
                    fileName: _jsxFileName,
                    lineNumber: 77,
                    columnNumber: 27
                  }, this);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 69,
                columnNumber: 21
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 65,
              columnNumber: 19
            }, this)]
          }, `ks${k}`, true, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 17
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./pages/dashboard/dashboard_admin.jsx":
/*!*********************************************!*\
  !*** ./pages/dashboard/dashboard_admin.jsx ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ dashboard_admin; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _layout_head_HeadDefault__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/layout/head/HeadDefault */ "./layout/head/HeadDefault.jsx");
/* harmony import */ var _components_container_dashboard_DashboardContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/container/dashboard/DashboardContainer */ "./components/container/dashboard/DashboardContainer.jsx");
/* harmony import */ var _layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/layout/MainLayout */ "./layout/MainLayout.jsx");


var _jsxFileName = "C:\\Users\\jyoti\\Desktop\\CDG Prototype\\CDG - IV\\pages\\dashboard\\dashboard_admin.jsx";
 //import TablePage from "@/components/table/TablePage";



function dashboard_admin() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__.default, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_layout_head_HeadDefault__WEBPACK_IMPORTED_MODULE_1__.default, {
        title: "Matrix CDG",
        description: "Admin Dashboard"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_container_dashboard_DashboardContainer__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ (function(module) {

"use strict";
module.exports = require("prop-types");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "react-chartjs-2":
/*!**********************************!*\
  !*** external "react-chartjs-2" ***!
  \**********************************/
/***/ (function(module) {

"use strict";
module.exports = require("react-chartjs-2");;

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ }),

/***/ "reactstrap":
/*!*****************************!*\
  !*** external "reactstrap" ***!
  \*****************************/
/***/ (function(module) {

"use strict";
module.exports = require("reactstrap");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/dashboard/dashboard_admin.jsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC8uL2NvbXBvbmVudHMvY2FyZHMvUHJvamVjdEhvcml6b250YWwuanN4Iiwid2VicGFjazovL25leHRqcy1yZWFjdHN0cmFwLy4vY29tcG9uZW50cy9jb250YWluZXIvY2hhcnRzL2JhckNoYXJ0LmpzIiwid2VicGFjazovL25leHRqcy1yZWFjdHN0cmFwLy4vY29tcG9uZW50cy9jb250YWluZXIvZGFzaGJvYXJkL0Rhc2hib2FyZENvbnRhaW5lci5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9jb21wb25lbnRzL2NvbnRhaW5lci9kYXNoYm9hcmQvRGFzaGJvYXJkUGFnZS5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9jb21wb25lbnRzL3RhYmxlL1RhYmxlQ29udGFpbmVyLmpzeCIsIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC8uL2NvbXBvbmVudHMvdGFibGUvVGFibGVQYWdlLmpzeCIsIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC8uL2NvbnN0YW50cy9tZW51cy5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9jb25zdGFudHMvdmFycy5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9sYXlvdXQvTWFpbkxheW91dC5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9sYXlvdXQvaGVhZC9IZWFkRGVmYXVsdC5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9sYXlvdXQvbmF2L05hdkJhci5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvLi9sYXlvdXQvbmF2L05hdkxlZnQuanN4Iiwid2VicGFjazovL25leHRqcy1yZWFjdHN0cmFwLy4vcGFnZXMvZGFzaGJvYXJkL2Rhc2hib2FyZF9hZG1pbi5qc3giLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC9leHRlcm5hbCBcInByb3AtdHlwZXNcIiIsIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvZXh0ZXJuYWwgXCJyZWFjdC1jaGFydGpzLTJcIiIsIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC9leHRlcm5hbCBcInJlYWN0LXJlZHV4XCIiLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC9leHRlcm5hbCBcInJlYWN0c3RyYXBcIiJdLCJuYW1lcyI6WyJQcm9qZWN0c0hvcml6b250YWwiLCJCYXJDaGFydCIsInN0YXRlIiwibGFiZWxzIiwiZGF0YXNldHMiLCJsYWJlbCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiYm9yZGVyV2lkdGgiLCJkYXRhIiwidGl0bGUiLCJkaXNwbGF5IiwidGV4dCIsImZvbnRTaXplIiwibGVnZW5kIiwicG9zaXRpb24iLCJEYXNoYm9hcmRDb250YWluZXIiLCJEYXNoYm9hcmRQYWdlIiwiVGFibGVDb250YWluZXIiLCJUYWJsZVBhZ2UiLCJNRU5VUyIsIm5hbWUiLCJhcyIsImhyZWYiLCJpY29uIiwiU1VCTUVOVVMiLCJUSEVNRSIsImRlc2NyaXB0aW9uIiwiTWFpbkxheW91dCIsIm1haW5Qcm9wcyIsImNoaWxkcmVuIiwiZGlzcGF0Y2giLCJzdG9yZUxheW91dCIsImFjdGl2ZUxpbmsiLCJ3aWRlTmF2Iiwid2lkdGgiLCJ3aWRlQ29udGVudCIsIm1hcmdpbkxlZnQiLCJpc09wZW4iLCJzZXRJc09wZW4iLCJ1c2VTdGF0ZSIsImlzVG9nZ2xlZCIsInNldElzVG9nZ2xlZCIsImlzV2lkZU5hdiIsInNldElzV2lkZU5hdiIsImlzV2lkZUNvbnRlbnQiLCJzZXRJc1dpZGVDb250ZW50IiwidG9nZ2xlIiwidG9nZ2xlTGVmdCIsInBhZGRpbmciLCJ0eXBlIiwiQUNUSU9OX1RZUEVTIiwiTEFZT1VUIiwiVE9HR0xFIiwiSGVhZERlZmF1bHQiLCJrZXl3b3JkIiwib2dUaXRsZSIsIm9nRGVzY3JpcHRpb24iLCJvZ0ltYWdlVXJsIiwib2dJbWFnZUFsdCIsIm9nVXJsIiwiTmF2QmFyIiwiTmF2TGVmdCIsInByb3BzIiwiaXRlbSIsImsiLCJpc0FjdGl2ZSIsInN1Ykl0ZW0iLCJhY3RpdmVNZW51cyIsInNwbGl0Iiwic3ViTGlua3MiLCJtYXAiLCJzdWJzIiwibCIsImlzU3ViQWN0aXZlIiwiZGFzaGJvYXJkX2FkbWluIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQWNBO0FBVWUsU0FBU0Esa0JBQVQsR0FBOEI7QUFDM0Msc0JBQ0U7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyxnRUFBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsK0JBQ0U7QUFBWSxtQkFBUyxFQUFDLDhCQUF0QjtBQUFBLGlDQUNFO0FBQUcsZ0JBQUksRUFBQyxHQUFSO0FBQVksaUJBQUssRUFBQyxlQUFsQjtBQUFBLG1DQUNFO0FBQ0UsdUJBQVMsRUFBQyxvQkFEWjtBQUVFLGlCQUFHLEVBQUMsVUFGTjtBQUdFLGlCQUFHLEVBQUM7QUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFhRTtBQUFLLGlCQUFTLEVBQUMsVUFBZjtBQUFBLCtCQUNFLDhEQUFDLDRDQUFEO0FBQU0sbUJBQVMsRUFBQyxZQUFoQjtBQUFBLGlDQUNFLDhEQUFDLGdEQUFEO0FBQUEsb0NBQ0UsOERBQUMsaURBQUQ7QUFBVyxpQkFBRyxFQUFDLElBQWY7QUFBb0IsdUJBQVMsRUFBQyxhQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUtFLDhEQUFDLDZDQUFEO0FBQU8sbUJBQUssTUFBWjtBQUFhLGtCQUFJLEVBQUMsSUFBbEI7QUFBdUIsd0JBQVUsTUFBakM7QUFBQSxxQ0FRRTtBQUFBLHdDQUNFO0FBQUEsMENBQ0U7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQU1FO0FBQUEsMENBQ0U7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFORixlQVdFO0FBQUEsMENBQ0U7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFYRixlQWdCRTtBQUFBLDBDQUNFO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUE0REQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RkQ7QUFDQTtBQUVlLFNBQVNDLFFBQVQsR0FBb0I7QUFDakMsUUFBTUMsS0FBSyxHQUFHO0FBQ1pDLFVBQU0sRUFBRSxDQUFDLFNBQUQsRUFBWSxVQUFaLEVBQXdCLE9BQXhCLEVBQWlDLE9BQWpDLEVBQTBDLEtBQTFDLENBREk7QUFFWkMsWUFBUSxFQUFFLENBQ1I7QUFDRUMsV0FBSyxFQUFFLHlCQURUO0FBRUVDLHFCQUFlLEVBQUUsaUJBRm5CO0FBR0VDLGlCQUFXLEVBQUUsZUFIZjtBQUlFQyxpQkFBVyxFQUFFLENBSmY7QUFLRUMsVUFBSSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsRUFBUyxFQUFULEVBQWEsRUFBYixFQUFpQixFQUFqQjtBQUxSLEtBRFE7QUFGRSxHQUFkO0FBYUEsc0JBQ0U7QUFBQSwyQkFDRSw4REFBQyxnREFBRDtBQUNFLFVBQUksRUFBRVAsS0FEUjtBQUVFLGFBQU8sRUFBRTtBQUNQUSxhQUFLLEVBQUU7QUFDTEMsaUJBQU8sRUFBRSxJQURKO0FBRUxDLGNBQUksRUFBRSw0QkFGRDtBQUdMQyxrQkFBUSxFQUFFO0FBSEwsU0FEQTtBQU1QQyxjQUFNLEVBQUU7QUFDTkgsaUJBQU8sRUFBRSxJQURIO0FBRU5JLGtCQUFRLEVBQUU7QUFGSjtBQU5EO0FBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQWtCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ0Q7QUFDZSxTQUFTQyxrQkFBVCxHQUE4QjtBQUMzQyxzQkFDRTtBQUFBLDJCQUNFLDhEQUFDLG1EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQUtELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQRDtBQUNBO0NBY0E7O0FBQ0E7QUFDQTtBQUVlLFNBQVNDLGFBQVQsR0FBeUI7QUFDdEMsc0JBQ0U7QUFBQSw0QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBS0U7QUFBSyxlQUFTLEVBQUMsaUZBQWY7QUFBQSw4QkFDRTtBQUNFLGlCQUFTLEVBQUMsTUFEWjtBQUVFLFdBQUcsRUFBQyxTQUZOO0FBR0UsV0FBRyxFQUFDLE9BSE47QUFJRSxhQUFLLEVBQUMsSUFKUjtBQUtFLGNBQU0sRUFBQztBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQVFFO0FBQUssaUJBQVMsRUFBQyxRQUFmO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLHdCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUkYsZUFZRTtBQUFLLGlCQUFTLEVBQUMsU0FBZjtBQUFBLCtCQUNFO0FBQVksbUJBQVMsRUFBQywrQkFBdEI7QUFBQSxpQ0FDRTtBQUFHLHFCQUFTLEVBQUMsS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEYsZUEwQkUsOERBQUMsMkNBQUQ7QUFBQSw4QkFDRSw4REFBQywyQ0FBRDtBQUFLLFVBQUUsRUFBQyxHQUFSO0FBQVksVUFBRSxFQUFDLEdBQWY7QUFBbUIsaUJBQVMsRUFBQyxNQUE3QjtBQUFBLCtCQUNFLDhEQUFDLDRDQUFEO0FBQU0sbUJBQVMsRUFBQyxZQUFoQjtBQUFBLGlDQUNFLDhEQUFDLGdEQUFEO0FBQUEsb0NBQ0UsOERBQUMsaURBQUQ7QUFBVyxpQkFBRyxFQUFDLElBQWY7QUFBb0IsdUJBQVMsRUFBQyxhQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUtFLDhEQUFDLDJDQUFEO0FBQUssdUJBQVMsRUFBQyxNQUFmO0FBQUEsc0NBQ0UsOERBQUMsMkNBQUQ7QUFDRSxrQkFBRSxFQUFDLEdBREw7QUFFRSx5QkFBUyxFQUFDLDBDQUZaO0FBQUEsd0NBSUU7QUFBRywyQkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKRixFQUl5QyxHQUp6QyxlQUtFO0FBQUEsaURBQ0ssOERBQUMsZ0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQVVFLDhEQUFDLDJDQUFEO0FBQUssa0JBQUUsRUFBQyxHQUFSO0FBQVkseUJBQVMsRUFBQyx1Q0FBdEI7QUFBQSx3Q0FDRTtBQUFHLDJCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLEVBQytDLEdBRC9DLGVBRUU7QUFBQSxpREFDSyw4REFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVZGLGVBZ0JFLDhEQUFDLDJDQUFEO0FBQ0Usa0JBQUUsRUFBQyxHQURMO0FBRUUseUJBQVMsRUFBQywwQ0FGWjtBQUFBLHdDQUlFO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSkYsRUFJNkMsR0FKN0MsZUFLRTtBQUFBLG9EQUNRLDhEQUFDLGdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFMRixlQWlDRSw4REFBQyw4Q0FBRDtBQUFRLG1CQUFLLEVBQUMsUUFBZDtBQUF1QixrQkFBSSxFQUFDLElBQTVCO0FBQWlDLG1CQUFLLE1BQXRDO0FBQUEsc0NBQ0U7QUFBRyx5QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUEyQ0UsOERBQUMsMkNBQUQ7QUFBSyxVQUFFLEVBQUMsR0FBUjtBQUFZLFVBQUUsRUFBQyxHQUFmO0FBQW1CLGlCQUFTLEVBQUMsTUFBN0I7QUFBQSwrQkFDRSw4REFBQyw0Q0FBRDtBQUFNLG1CQUFTLEVBQUMsWUFBaEI7QUFBQSxpQ0FDRSw4REFBQyxnREFBRDtBQUFBLG9DQUNFLDhEQUFDLGlEQUFEO0FBQVcsaUJBQUcsRUFBQyxJQUFmO0FBQW9CLHVCQUFTLEVBQUMsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFLRSw4REFBQywyQ0FBRDtBQUFLLHVCQUFTLEVBQUMsTUFBZjtBQUFBLHFDQUNFLDhEQUFDLDJDQUFEO0FBQUssa0JBQUUsRUFBQyxFQUFSO0FBQVcseUJBQVMsRUFBQyw2QkFBckI7QUFBQSx1Q0FDRSw4REFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EzQ0YsZUFvSEUsOERBQUMsMkNBQUQ7QUFBSyxVQUFFLEVBQUMsR0FBUjtBQUFZLFVBQUUsRUFBQyxHQUFmO0FBQW1CLGlCQUFTLEVBQUMsTUFBN0I7QUFBQSwrQkFDRSw4REFBQyw0Q0FBRDtBQUFNLG1CQUFTLEVBQUMsWUFBaEI7QUFBQSxpQ0FDRSw4REFBQyxnREFBRDtBQUFBLG9DQUNFLDhEQUFDLGlEQUFEO0FBQVcsaUJBQUcsRUFBQyxJQUFmO0FBQW9CLHVCQUFTLEVBQUMsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFLRSw4REFBQywyQ0FBRDtBQUFLLHVCQUFTLEVBQUMsTUFBZjtBQUFBLHFDQUNFLDhEQUFDLDJDQUFEO0FBQUssa0JBQUUsRUFBQyxFQUFSO0FBQVcseUJBQVMsRUFBQyw2QkFBckI7QUFBQSx1Q0FDRSw4REFBQyxxRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FwSEYsZUFrUEUsOERBQUMsMkNBQUQ7QUFBSyxVQUFFLEVBQUMsSUFBUjtBQUFhLFVBQUUsRUFBQyxJQUFoQjtBQUFxQixpQkFBUyxFQUFDLE1BQS9CO0FBQUEsK0JBQ0UsOERBQUMsNENBQUQ7QUFBTSxtQkFBUyxFQUFDLFlBQWhCO0FBQUEsaUNBQ0UsOERBQUMsZ0RBQUQ7QUFBQSxvQ0FDRSw4REFBQyxpREFBRDtBQUFXLGlCQUFHLEVBQUMsSUFBZjtBQUFvQix1QkFBUyxFQUFDLGFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBTUUsOERBQUMsd0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWxQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUExQkY7QUFBQSxrQkFERjtBQTZSRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqVEQ7QUFFZSxTQUFTQyxjQUFULEdBQTBCO0FBQ3ZDLHNCQUNFO0FBQUEsdUNBQ1MsOERBQUMsK0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURUO0FBQUEsa0JBREY7QUFLRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkQ7QUFFZSxTQUFTQyxTQUFULEdBQXFCO0FBQ2xDO0FBQ0Esc0JBQ0U7QUFBQSw0QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFFRTtBQUFLLGVBQVMsRUFBQyxNQUFmO0FBQUEsNkJBQ0UsOERBQUMsMkNBQUQ7QUFBQSwrQkFtRUUsOERBQUMsMkNBQUQ7QUFBSyxZQUFFLEVBQUMsSUFBUjtBQUFBLGtDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRSw4REFBQyw2Q0FBRDtBQUFPLG1CQUFPLE1BQWQ7QUFBZSxpQkFBSyxNQUFwQjtBQUFBLG9DQUNFO0FBQUEscUNBQ0U7QUFBQSx3Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBU0U7QUFBQSxzQ0FDRTtBQUFBLHdDQUNFO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFIRixlQUlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQU9FO0FBQUEsd0NBQ0U7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVBGLGVBYUU7QUFBQSx3Q0FDRTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRjtBQUFBLGtCQURGO0FBNklELEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqSkQ7QUFDQSxNQUFNQyxLQUFLLEdBQUcsQ0FDWjtBQUNFQyxNQUFJLEVBQUUsRUFEUjtBQUVFQyxJQUFFLEVBQUUsR0FGTjtBQUdFQyxNQUFJLEVBQUUsc0JBSFI7QUFJRWxCLE9BQUssRUFBRSxXQUpUO0FBS0VtQixNQUFJLEVBQUU7QUFMUixDQURZLEVBUVo7QUFDRUgsTUFBSSxFQUFFLFVBRFI7QUFFRUMsSUFBRSxFQUFFLEdBRk47QUFHRUMsTUFBSSxFQUFFLGFBSFI7QUFJRWxCLE9BQUssRUFBRSxVQUpUO0FBS0VtQixNQUFJLEVBQUU7QUFMUixDQVJZLEVBZVo7QUFDRUgsTUFBSSxFQUFFLGFBRFI7QUFFRUMsSUFBRSxFQUFFLEdBRk47QUFHRUMsTUFBSSxFQUFFLGVBSFI7QUFJRWxCLE9BQUssRUFBRSxhQUpUO0FBS0VtQixNQUFJLEVBQUU7QUFMUixDQWZZLENBc0JaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFuQ1ksQ0FBZCxDLENBcUNBOztBQUNBLE1BQU1DLFFBQVEsR0FBRyxDQUNmO0FBQ0VKLE1BQUksRUFBRSxTQURSO0FBRUVDLElBQUUsRUFBRSxHQUZOO0FBR0VDLE1BQUksRUFBRSxpQkFIUjtBQUlFbEIsT0FBSyxFQUFFLFNBSlQ7QUFLRW1CLE1BQUksRUFBRSxFQUxSLENBTUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUEvRUYsQ0FEZSxDQUFqQjs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDQSxNQUFNRSxLQUFLLEdBQUc7QUFDWmhCLE9BQUssRUFBRSxjQURLO0FBRVppQixhQUFXLEVBQUU7QUFGRCxDQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRWUsU0FBU0MsVUFBVCxDQUFvQkMsU0FBcEIsRUFBK0I7QUFDNUMsUUFBTTtBQUFFQyxZQUFGO0FBQVlDLFlBQVo7QUFBc0JDLGVBQXRCO0FBQW1DQztBQUFuQyxNQUFrREosU0FBeEQ7QUFFQTs7QUFDQSxRQUFNSyxPQUFPLEdBQUc7QUFBRUMsU0FBSyxFQUFFO0FBQVQsR0FBaEI7QUFDQSxRQUFNQyxXQUFXLEdBQUc7QUFBRUMsY0FBVSxFQUFFO0FBQWQsR0FBcEI7QUFFQSxRQUFNO0FBQUEsT0FBQ0MsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JDLCtDQUFRLENBQUMsS0FBRCxDQUFwQztBQUNBLFFBQU07QUFBQSxPQUFDQyxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QkYsK0NBQVEsQ0FBQyxLQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNHLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCSiwrQ0FBUSxtQkFBTU4sT0FBTixFQUExQztBQUNBLFFBQU07QUFBQSxPQUFDVyxhQUFEO0FBQUEsT0FBZ0JDO0FBQWhCLE1BQW9DTiwrQ0FBUSxtQkFBTUosV0FBTixFQUFsRDs7QUFFQSxRQUFNVyxNQUFNLEdBQUcsTUFBTVIsU0FBUyxDQUFDLENBQUNELE1BQUYsQ0FBOUI7O0FBQ0EsUUFBTVUsVUFBVSxHQUFHLE1BQU07QUFDdkJOLGdCQUFZLENBQUMsQ0FBQ0QsU0FBRixDQUFaOztBQUNBLFFBQUlULFdBQVcsQ0FBQ2UsTUFBaEIsRUFBd0I7QUFDdEJILGtCQUFZLG1CQUFNVixPQUFOLEVBQVo7QUFDQVksc0JBQWdCLG1CQUFNVixXQUFOLEVBQWhCO0FBQ0QsS0FIRCxNQUdPO0FBQ0xRLGtCQUFZLENBQUM7QUFBRVQsYUFBSyxFQUFFLENBQVQ7QUFBWWMsZUFBTyxFQUFFO0FBQXJCLE9BQUQsQ0FBWjtBQUNBSCxzQkFBZ0IsQ0FBQztBQUFFVCxrQkFBVSxFQUFFO0FBQWQsT0FBRCxDQUFoQjtBQUNEOztBQUNETixZQUFRLENBQUM7QUFDUG1CLFVBQUksRUFBRUMsWUFBWSxDQUFDQyxNQUFiLENBQW9CQyxNQURuQjtBQUVQTixZQUFNLEVBQUVOO0FBRkQsS0FBRCxDQUFSO0FBSUQsR0FiRDs7QUFlQSxzQkFDRTtBQUFBLDRCQUNFLDhEQUFDLGdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUVFLDhEQUFDLGlEQUFEO0FBQVcsV0FBSyxNQUFoQjtBQUFpQixlQUFTLEVBQUMsU0FBM0I7QUFBQSw2QkFDRSw4REFBQywyQ0FBRDtBQUFBLGdDQUNFLDhEQUFDLDJDQUFEO0FBQUssbUJBQVMsRUFBQyxjQUFmO0FBQThCLGVBQUssRUFBRUUsU0FBckM7QUFBQSxpQ0FDRSw4REFBQyxpREFBRDtBQUFTLHNCQUFVLEVBQUVWO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUsOERBQUMsMkNBQUQ7QUFBSyxtQkFBUyxFQUFDLGlCQUFmO0FBQWlDLGVBQUssRUFBRVksYUFBeEM7QUFBQSxvQkFDR2Y7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRjtBQUFBLGtCQURGO0FBZ0JELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEREO0FBQ0E7QUFDQTtBQUNBO0FBRWUsU0FBU3dCLFdBQVQsQ0FBcUI7QUFDbEM1QyxPQURrQztBQUVsQ2lCLGFBRmtDO0FBR2xDNEIsU0FIa0M7QUFJbENDLFNBSmtDO0FBS2xDQyxlQUxrQztBQU1sQ0MsWUFOa0M7QUFPbENDLFlBUGtDO0FBUWxDQztBQVJrQyxDQUFyQixFQVNaO0FBQ0Qsc0JBQ0UsOERBQUMsa0RBQUQ7QUFBQSw0QkFDRTtBQUFBLGlCQUNHbEQsS0FESCxTQUNhZ0Isd0RBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRTtBQUFNLFNBQUcsRUFBQyxNQUFWO0FBQWlCLFVBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEYsZUFRRTtBQUFNLFVBQUksRUFBQyxPQUFYO0FBQW1CLGFBQU8sRUFBRWhCO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFSRixlQVNFO0FBQU0sVUFBSSxFQUFDLGFBQVg7QUFBeUIsYUFBTyxFQUFFaUI7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVRGLGVBVUU7QUFBTSxVQUFJLEVBQUMsVUFBWDtBQUFzQixhQUFPLEVBQUU0QjtBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVkYsZUFhRTtBQUFNLGNBQVEsRUFBQyxVQUFmO0FBQTBCLGFBQU8sRUFBRUM7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWJGLGVBY0U7QUFBTSxjQUFRLEVBQUMsZ0JBQWY7QUFBZ0MsYUFBTyxFQUFFQztBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZEYsZUFlRTtBQUFNLGNBQVEsRUFBQyxRQUFmO0FBQXdCLGFBQU8sRUFBRUc7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWZGLGVBZ0JFO0FBQU0sY0FBUSxFQUFDLFVBQWY7QUFBMEIsYUFBTyxFQUFFRjtBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaEJGLGVBaUJFO0FBQU0sY0FBUSxFQUFDLGNBQWY7QUFBOEIsYUFBTyxFQUFFQTtBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBakJGLGVBa0JFO0FBQU0sY0FBUSxFQUFDLGNBQWY7QUFBOEIsYUFBTyxFQUFFQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbEJGLGVBbUJFO0FBQU0sY0FBUSxFQUFDLGVBQWY7QUFBK0IsYUFBTyxFQUFDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFuQkYsZUFvQkU7QUFBTSxjQUFRLEVBQUMsZ0JBQWY7QUFBZ0MsYUFBTyxFQUFDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFwQkYsZUFxQkU7QUFBTSxjQUFRLEVBQUMsaUJBQWY7QUFBaUMsYUFBTyxFQUFDO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUF5QkQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4Q0Q7QUFDQTtBQWVlLFNBQVNFLE1BQVQsQ0FBZ0I7QUFDN0I7QUFDQXZCLFFBRjZCO0FBRzdCRyxXQUg2Qjs7QUFJN0I7QUFDQU0sUUFMNkI7QUFNN0JDO0FBTjZCLENBQWhCLEVBT1o7QUFDRCxzQkFDRTtBQUFLLGFBQVMsRUFBQyxXQUFmO0FBQUEsMkJBQ0UsOERBQUMsOENBQUQ7QUFBUSxXQUFLLEVBQUMsU0FBZDtBQUF3QixVQUFJLE1BQTVCO0FBQTZCLFlBQU0sRUFBQyxJQUFwQztBQUF5QyxXQUFLLEVBQUMsS0FBL0M7QUFBQSw4QkFDRSw4REFBQyxtREFBRDtBQUFhLFlBQUksRUFBQyxHQUFsQjtBQUFBLCtCQUNFO0FBQUssYUFBRyxFQUFDLFNBQVQ7QUFBbUIsYUFBRyxFQUFDLE1BQXZCO0FBQThCLG1CQUFTLEVBQUMsRUFBeEM7QUFBMkMsZ0JBQU0sRUFBQyxJQUFsRDtBQUF1RCxlQUFLLEVBQUM7QUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUlFLDhEQUFDLHFEQUFEO0FBQWUsZUFBTyxFQUFFRCxNQUF4QjtBQUFnQyxhQUFLLEVBQUM7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpGLGVBS0UsOERBQUMsZ0RBQUQ7QUFBVSxjQUFNLEVBQUVULE1BQWxCO0FBQTBCLGNBQU0sTUFBaEM7QUFBQSxnQ0FDRSw4REFBQywyQ0FBRDtBQUFLLG1CQUFTLEVBQUMsU0FBZjtBQUF5QixnQkFBTSxNQUEvQjtBQUFBLGlDQWlCRSw4REFBQyw0REFBRDtBQUFzQixlQUFHLE1BQXpCO0FBQTBCLG9CQUFRLE1BQWxDO0FBQUEsb0NBQ0UsOERBQUMsc0RBQUQ7QUFBZ0IsaUJBQUcsTUFBbkI7QUFBb0IsbUJBQUs7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUVFLDhEQUFDLG9EQUFEO0FBQWMsbUJBQUssTUFBbkI7QUFBQSxzQ0FDRSw4REFBQyxvREFBRDtBQUFjLG1CQUFHLEVBQUMsS0FBbEI7QUFBQSx1Q0FDRSw4REFBQywrQ0FBRDtBQUFTLHNCQUFJLEVBQUMsYUFBZDtBQUE0QiwyQkFBUyxFQUFDLGNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQU1FLDhEQUFDLG9EQUFEO0FBQWMsbUJBQUcsRUFBQyxLQUFsQjtBQUFBLHVDQUNFLDhEQUFDLCtDQUFEO0FBQVMsc0JBQUksRUFBQyxlQUFkO0FBQThCLDJCQUFTLEVBQUMsY0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU5GLGVBV0UsOERBQUMsb0RBQUQ7QUFBYyxtQkFBRyxFQUFDLEtBQWxCO0FBQUEsdUNBQ0UsOERBQUMsK0NBQUQ7QUFBUyxzQkFBSSxFQUFDLGVBQWQ7QUFBOEIsMkJBQVMsRUFBQyxjQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWEYsZUFpQkUsOERBQUMsb0RBQUQ7QUFBYyxtQkFBRyxFQUFDLEtBQWxCO0FBQUEsdUNBQ0UsOERBQUMsK0NBQUQ7QUFBUyxzQkFBSSxFQUFDLGFBQWQ7QUFBNEIsMkJBQVMsRUFBQyxjQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQStDRSw4REFBQyxrREFBRDtBQUFZLG1CQUFTLEVBQUMsOENBQXRCO0FBQUEsa0NBQ0U7QUFDRSxlQUFHLEVBQUMsc0JBRE47QUFFRSxxQkFBUyxFQUFDO0FBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXFGRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdHRDtBQVNBO0FBRWUsU0FBU3dCLE9BQVQsQ0FBaUJDLEtBQWpCLEVBQXdCO0FBQ3JDLFFBQU07QUFBRTlCO0FBQUYsTUFBaUI4QixLQUF2QjtBQUNBLHNCQUNFO0FBQUEsNEJBQ0U7QUFBSSxlQUFTLEVBQUMsVUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUU7QUFBSyxlQUFTLE1BQWQ7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFXLGFBQUssTUFBaEI7QUFBaUIsaUJBQVMsRUFBQyxxQkFBM0I7QUFBaUQsV0FBRyxFQUFDLEtBQXJEO0FBQUEsa0JBQ0czQyx1REFBQSxDQUFVLENBQUM0QyxJQUFELEVBQU9DLENBQVAsS0FBYTtBQUN0QixnQkFBTUMsUUFBUSxHQUFHakMsVUFBVSxLQUFLK0IsSUFBSSxDQUFDM0MsSUFBcEIsR0FBMkIsSUFBM0IsR0FBa0MsS0FBbkQ7QUFDQSw4QkFDRSw4REFBQyxxREFBRDtBQUVFLGtCQUFNLEVBQUU2QyxRQUZWO0FBR0UsZUFBRyxFQUFFRixJQUFJLENBQUMxQyxFQUhaO0FBSUUsZ0JBQUksRUFBRSxHQUpSO0FBQUEsdUJBTUcwQyxJQUFJLENBQUN4QyxJQUFMLGlCQUFhO0FBQUcsdUJBQVMsRUFBRXdDLElBQUksQ0FBQ3hDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTmhCLE9BTWdEd0MsSUFBSSxDQUFDM0QsS0FOckQ7QUFBQSxhQUNRLElBQUc0RCxDQUFFLEVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQVVELFNBWkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBbUJFO0FBQUksZUFBUyxFQUFDLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFuQkYsZUFvQkU7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFXLGFBQUssTUFBaEI7QUFBaUIsaUJBQVMsRUFBQyxxQkFBM0I7QUFBaUQsV0FBRyxFQUFDLEtBQXJEO0FBQUEsa0JBQ0d4QywwREFBQSxDQUFhLENBQUMwQyxPQUFELEVBQVVGLENBQVYsS0FBZ0I7QUFDNUIsZ0JBQU1DLFFBQVEsR0FBR2pDLFVBQVUsS0FBS2tDLE9BQU8sQ0FBQzlDLElBQXZCLEdBQThCLElBQTlCLEdBQXFDLEtBQXREO0FBQ0EsZ0JBQU0rQyxXQUFXLEdBQUduQyxVQUFVLElBQUlBLFVBQVUsQ0FBQ29DLEtBQVgsQ0FBaUIsR0FBakIsQ0FBbEM7QUFDQSxpQkFDRyxDQUFDRixPQUFPLENBQUNHLFFBQVQsaUJBQ0MsOERBQUMscURBQUQ7QUFFRSxrQkFBTSxFQUFFSixRQUZWO0FBR0UsZUFBRyxFQUFFQyxPQUFPLENBQUM3QyxFQUhmO0FBSUUsZ0JBQUksRUFBRSxHQUpSO0FBQUEsdUJBTUc2QyxPQUFPLENBQUMzQyxJQUFSLGlCQUFnQjtBQUFHLHVCQUFTLEVBQUUyQyxPQUFPLENBQUMzQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU5uQixVQU9HMkMsT0FBTyxDQUFDOUQsS0FQWDtBQUFBLGFBQ1EsSUFBRzRELENBQUUsRUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGlCQVdFLDhEQUFDLHFEQUFEO0FBRUUsZUFBRyxFQUFDO0FBQ0o7QUFIRjtBQUFBLG9DQUtFO0FBQ0Usa0JBQUksRUFBRUUsT0FBTyxDQUFDNUMsSUFEaEI7QUFFRSx1QkFBUyxFQUFDLGlCQUZaO0FBR0UsZ0JBQUUsRUFBRyxtQkFBa0IwQyxDQUFFLEVBSDNCO0FBQUEseUJBS0dFLE9BQU8sQ0FBQzNDLElBQVIsaUJBQWdCO0FBQUcseUJBQVMsRUFBRTJDLE9BQU8sQ0FBQzNDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTG5CLFVBTUcyQyxPQUFPLENBQUM5RCxLQU5YO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFMRixlQWFFLDhEQUFDLDREQUFEO0FBQ0UscUJBQU8sRUFBRyxtQkFBa0I0RCxDQUFFLEVBRGhDLENBRUU7QUFGRjtBQUFBLHFDQUlFLDhEQUFDLDJDQUFEO0FBQUssd0JBQVEsTUFBYjtBQUFjLHlCQUFTLEVBQUMsTUFBeEI7QUFBQSwwQkFDR0UsT0FBTyxDQUFDRyxRQUFSLENBQWlCQyxHQUFqQixDQUFxQixDQUFDQyxJQUFELEVBQU9DLENBQVAsS0FBYTtBQUNqQyx3QkFBTUMsV0FBVyxHQUNmTixXQUFXLElBQUlBLFdBQVcsQ0FBQyxDQUFELENBQVgsS0FBbUJJLElBQUksQ0FBQ25ELElBQXZDLEdBQ0ksSUFESixHQUVJLEtBSE47QUFLQSxzQ0FDRSw4REFBQywrQ0FBRDtBQUF1QiwwQkFBTSxFQUFFcUQsV0FBVyxLQUFLLElBQS9DO0FBQUEsMkNBQ0UsOERBQUMsK0NBQUQ7QUFBUywwQkFBSSxFQUFFRixJQUFJLENBQUNqRCxJQUFwQjtBQUFBLGdDQUEyQmlELElBQUksQ0FBQ25FO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixxQkFBZSxJQUFHb0UsQ0FBRSxFQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGO0FBS0QsaUJBWEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFiRjtBQUFBLGFBQ1EsS0FBSVIsQ0FBRSxFQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWko7QUErQ0QsU0FsREE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXBCRjtBQUFBLGtCQURGO0FBOEVELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NDMUZEOztBQUNBO0FBQ0E7QUFDZSxTQUFTVSxlQUFULEdBQTJCO0FBQ3hDLHNCQUNFO0FBQUEsMkJBQ0UsOERBQUMsdURBQUQ7QUFBQSw4QkFDRSw4REFBQyw2REFBRDtBQUFhLGFBQUssRUFBQyxZQUFuQjtBQUFnQyxtQkFBVyxFQUFDO0FBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFLDhEQUFDLHVGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQVFELEM7Ozs7Ozs7Ozs7O0FDYkQsdUM7Ozs7Ozs7Ozs7O0FDQUEsd0M7Ozs7Ozs7Ozs7O0FDQUEsbUM7Ozs7Ozs7Ozs7O0FDQUEsNkM7Ozs7Ozs7Ozs7O0FDQUEseUM7Ozs7Ozs7Ozs7O0FDQUEsbUQ7Ozs7Ozs7Ozs7O0FDQUEsd0MiLCJmaWxlIjoicGFnZXMvZGFzaGJvYXJkL2Rhc2hib2FyZF9hZG1pbi5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgQ29sLFxyXG4gIFJvdyxcclxuICBDYXJkLFxyXG4gIENhcmRUaXRsZSxcclxuICBDYXJkQm9keSxcclxuICBDYXJkVGV4dCxcclxuICBUYWJsZSxcclxuICBOYXYsXHJcbiAgTmF2SXRlbSxcclxuICBOYXZMaW5rLFxyXG4gIFRhYkNvbnRlbnQsXHJcbiAgVGFiUGFuZSxcclxufSBmcm9tIFwicmVhY3RzdHJhcFwiO1xyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBGb3JtLFxyXG4gIEZvcm1Sb3csXHJcbiAgRm9ybUdyb3VwLFxyXG4gIExhYmVsLFxyXG4gIElucHV0LFxyXG4gIEZvcm1UZXh0LFxyXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9qZWN0c0hvcml6b250YWwoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IHAtMyBhbGlnbi1pdGVtcy1jZW50ZXIgdGV4dC1ncmV5LTUwIGJnLXdoaXRlIGJveC1zaGFkb3dcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zbS0zXCI+XHJcbiAgICAgICAgICA8YmxvY2txdW90ZSBjbGFzc05hbWU9XCJibG9ja3F1b3RlIHRleHQtbGVmdCBwLTAgbS0wXCI+XHJcbiAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgdGl0bGU9XCJQcm9qZWN0IEltYWdlXCI+XHJcbiAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXItMyBpbWctdGh1bWJuYWlsXCJcclxuICAgICAgICAgICAgICAgIHNyYz1cIi9NQVQuanBnXCJcclxuICAgICAgICAgICAgICAgIGFsdD1cIlByb2ZpbGUgSW1hZ2VcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgIDwvYmxvY2txdW90ZT5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc20tOVwiPlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiaC0xMDAgbWItMFwiPlxyXG4gICAgICAgICAgICA8Q2FyZEJvZHk+XHJcbiAgICAgICAgICAgICAgPENhcmRUaXRsZSB0YWc9XCJoNFwiIGNsYXNzTmFtZT1cImhlYWRsaW5lLW1tXCI+XHJcbiAgICAgICAgICAgICAgICBNYXRyaXgtU3lzdGVtIDFBXHJcbiAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XHJcbiAgICAgICAgICAgICAgey8qIDxDYXJkVGV4dD48L0NhcmRUZXh0PiAqL31cclxuICAgICAgICAgICAgICA8VGFibGUgaG92ZXIgc2l6ZT1cIm1kXCIgYm9yZGVybGVzcz5cclxuICAgICAgICAgICAgICAgIHsvKiA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICA8dGg+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoPkZpcnN0IE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aD5Vc2VybmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8L3RoZWFkPiAqL31cclxuICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjE8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD5TeXN0ZW0gTG9jYXRpb248L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD41ODYgR3VsZiBBdmVudWUsIFN0YXRlbiBJc2xhbmQsIE5ldyBZb3JrPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD5TeXN0ZW0gU2l6ZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkPjMsMjQ2IGtXPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD5VdGlsaXR5PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQ+Q29uRWRpc29uPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD5TdWJzY3JpcHRpb24gU3RhdHVzPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQ+MTAwJTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgIDwvVGFibGU+XHJcbiAgICAgICAgICAgICAgey8qIDxCdXR0b24+R28gc29tZXdoZXJlPC9CdXR0b24+ICovfVxyXG4gICAgICAgICAgICA8L0NhcmRCb2R5PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCYXIgfSBmcm9tIFwicmVhY3QtY2hhcnRqcy0yXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCYXJDaGFydCgpIHtcclxuICBjb25zdCBzdGF0ZSA9IHtcclxuICAgIGxhYmVsczogW1wiSmFudWFyeVwiLCBcIkZlYnJ1YXJ5XCIsIFwiTWFyY2hcIiwgXCJBcHJpbFwiLCBcIk1heVwiXSxcclxuICAgIGRhdGFzZXRzOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBsYWJlbDogXCJTeXN0ZW0gUHJvZHVjdGlvbiAoa1doKVwiLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJyZ2IoNzAsMTMwLDE4MClcIixcclxuICAgICAgICBib3JkZXJDb2xvcjogXCJyZ2JhKDAsMCwwLDApXCIsXHJcbiAgICAgICAgYm9yZGVyV2lkdGg6IDIsXHJcbiAgICAgICAgZGF0YTogWzY1LCA1OSwgODAsIDgxLCA1Nl0sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8QmFyXHJcbiAgICAgICAgZGF0YT17c3RhdGV9XHJcbiAgICAgICAgb3B0aW9ucz17e1xyXG4gICAgICAgICAgdGl0bGU6IHtcclxuICAgICAgICAgICAgZGlzcGxheTogdHJ1ZSxcclxuICAgICAgICAgICAgdGV4dDogXCJBdmVyYWdlIFJhaW5mYWxsIHBlciBtb250aFwiLFxyXG4gICAgICAgICAgICBmb250U2l6ZTogMjAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgbGVnZW5kOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IHRydWUsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiIsImltcG9ydCBEYXNoYm9hcmRQYWdlIGZyb20gXCIuL0Rhc2hib2FyZFBhZ2VcIjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGFzaGJvYXJkQ29udGFpbmVyKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8RGFzaGJvYXJkUGFnZSAvPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iLCIvL2ltcG9ydCBSZWFjdCwgeyBtZW1vIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQge1xyXG4gIENhcmQsXHJcbiAgQ2FyZEJvZHksXHJcbiAgQ2FyZFRpdGxlLFxyXG4gIENhcmRUZXh0LFxyXG4gIENhcmRGb290ZXIsXHJcbiAgVGFibGUsXHJcbiAgTWVkaWEsXHJcbiAgUm93LFxyXG4gIENvbCxcclxuICBCdXR0b24sXHJcbiAgQmFkZ2UsXHJcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcclxuaW1wb3J0IEJhckNoYXJ0IGZyb20gXCIuLi9jaGFydHMvYmFyQ2hhcnRcIjtcclxuLy9pbXBvcnQgUHJvamVjdENhcmQgZnJvbSBcIi4uL2NhcmQvcHJvamVjdHNcIjtcclxuaW1wb3J0IFRhYmxlQ29udGFpbmVyIGZyb20gXCJAL2NvbXBvbmVudHMvdGFibGUvVGFibGVDb250YWluZXJcIjtcclxuaW1wb3J0IFByb2plY3RzSG9yaXpvbnRhbCBmcm9tIFwiQC9jb21wb25lbnRzL2NhcmRzL1Byb2plY3RIb3Jpem9udGFsXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXNoYm9hcmRQYWdlKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8aDE+IFNvbGFyIEFkbWluIERhc2hib2FyZDwvaDE+XHJcbiAgICAgIDxwPlxyXG4gICAgICAgIHsvKiBXZWxjb21lLCB0aGlzIGlzIHlvdXIgPGNvZGU+cGFnZXMvZGFzaGJvYXJkLmpzeDwvY29kZT4sIHBsZWFzZSBjb250aW51ZS4gKi99XHJcbiAgICAgIDwvcD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggcC0zIG15LTMgYWxpZ24taXRlbXMtY2VudGVyIHRleHQtd2hpdGUtNTAgYmctZ3JhZGllbnQtcHJpbWFyeSBib3gtc2hhZG93XCI+XHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibXItM1wiXHJcbiAgICAgICAgICBzcmM9XCIvTVMucG5nXCJcclxuICAgICAgICAgIGFsdD1cIkJyYW5kXCJcclxuICAgICAgICAgIHdpZHRoPVwiNDhcIlxyXG4gICAgICAgICAgaGVpZ2h0PVwiNDhcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsaC0xMDBcIj5cclxuICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJtYi0wIHRleHQtd2hpdGUgbGgtMTAwXCI+Q29tbXVuaXR5IFNvbGFyIENERzwvaDY+XHJcbiAgICAgICAgICA8c21hbGw+TWF4U29sYXI8L3NtYWxsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtYXV0b1wiPlxyXG4gICAgICAgICAgPGJsb2NrcXVvdGUgY2xhc3NOYW1lPVwiYmxvY2txdW90ZSB0ZXh0LXJpZ2h0IHAtMCBtLTBcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibS0wXCI+V2VsY29tZSB0byB0aGUgQ0RHIEFkbWluIERhc2hib2FyZDwvcD5cclxuICAgICAgICAgICAgey8qIDxmb290ZXIgY2xhc3NOYW1lPVwiYmxvY2txdW90ZS1mb290ZXIgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgV2ViIEFkbWluaXN0cmF0b3IsIDxjaXRlIHRpdGxlPVwiU291cmNlIFRpdGxlXCI+V2ViIEJvdDwvY2l0ZT5cclxuICAgICAgICAgICAgICA8L2Zvb3Rlcj4gKi99XHJcbiAgICAgICAgICA8L2Jsb2NrcXVvdGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8Um93PlxyXG4gICAgICAgIDxDb2wgbWQ9XCI2XCIgbGc9XCI0XCIgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiaC0xMDAgbWItMlwiPlxyXG4gICAgICAgICAgICA8Q2FyZEJvZHk+XHJcbiAgICAgICAgICAgICAgPENhcmRUaXRsZSB0YWc9XCJoNFwiIGNsYXNzTmFtZT1cImhlYWRsaW5lLW1tXCI+XHJcbiAgICAgICAgICAgICAgICBQb3J0Zm9saW8gU3VtbWFyeVxyXG4gICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxyXG4gICAgICAgICAgICAgIHsvKiA8Q2FyZFRleHQ+ICovfVxyXG4gICAgICAgICAgICAgIDxSb3cgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPENvbFxyXG4gICAgICAgICAgICAgICAgICB4cz1cIjRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkLWlubGluZSBhbGlnbi1pdGVtcy1jZW50ZXIgdGV4dC1zdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXVzZXJzIGZhLTN4XCI+PC9pPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgMjUgPENhcmRUZXh0PlN1YnNjcmliZXJzPC9DYXJkVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICA8Q29sIHhzPVwiNFwiIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlciB0ZXh0LWluZm9cIj5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXNvbGFyLXBhbmVsIGZhLTN4XCI+PC9pPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgMTAgPENhcmRUZXh0PlByb2plY3RzPC9DYXJkVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICA8Q29sXHJcbiAgICAgICAgICAgICAgICAgIHhzPVwiNFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlciB0ZXh0LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYXMgZmFzIGZhLWNvaW5zIGZhLTN4XCI+PC9pPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgJCA3NUsgPENhcmRUZXh0PlJldmVudWU8L0NhcmRUZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICB7LyogPC9DYXJkVGV4dD4gKi99XHJcbiAgICAgICAgICAgICAgey8qIDxDYXJkRm9vdGVyPiAqL31cclxuICAgICAgICAgICAgICA8QnV0dG9uIGNvbG9yPVwiZGFuZ2VyXCIgc2l6ZT1cIm1kXCIgYmxvY2s+XHJcbiAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hhcnQtYmFyXCI+PC9pPiBzdGF0aXN0aWNcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICB7LyogPC9DYXJkRm9vdGVyPiAqL31cclxuICAgICAgICAgICAgPC9DYXJkQm9keT5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgICA8Q29sIG1kPVwiNlwiIGxnPVwiNFwiIGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImgtMTAwIG1iLTJcIj5cclxuICAgICAgICAgICAgPENhcmRCb2R5PlxyXG4gICAgICAgICAgICAgIDxDYXJkVGl0bGUgdGFnPVwiaDRcIiBjbGFzc05hbWU9XCJoZWFkbGluZS1tbVwiPlxyXG4gICAgICAgICAgICAgICAgU3lzdGVtIFByb2R1Y3Rpb24gLSAyMDIxIChZVEQpXHJcbiAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XHJcbiAgICAgICAgICAgICAgey8qIDxDYXJkVGV4dD4gKi99XHJcbiAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8Q29sIHhzPVwiXCIgY2xhc3NOYW1lPVwiZC1pbmxpbmUgYWxpZ24taXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCYXJDaGFydCAvPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPENhcmRUZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0YWc9XCJhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCIjXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLWljb25zIGljb24tcm91bmRlZC1jaXJjbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhYiBmYS1mYWNlYm9va1wiPjwvaT4gMTI5MFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPVwiNFwiIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGFnPVwiYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci1pY29ucyBpY29uLXJvdW5kZWQtY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYWIgZmEtdHdpdHRlclwiPjwvaT4gMjMyNFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPVwiNFwiIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGFnPVwiYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci1pY29ucyBpY29uLXJvdW5kZWQtY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYWIgZmEtaW5zdGFncmFtXCI+PC9pPiAxMjM0MVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPVwiNFwiIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGFnPVwiYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci1pY29ucyBpY29uLXJvdW5kZWQtY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYWIgZmEtbGlua2VkaW5cIj48L2k+IDEzMzFcclxuICAgICAgICAgICAgICAgICAgICA8L0NhcmRUZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz1cIjRcIiBjbGFzc05hbWU9XCJkLWlubGluZSBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZFRleHRcclxuICAgICAgICAgICAgICAgICAgICAgIHRhZz1cImFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj1cIiNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3ItaWNvbnMgaWNvbi1yb3VuZGVkLWNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFiIGZhLXBpbnRlcmVzdFwiPjwvaT4gNDEyNFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPVwiNFwiIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGFnPVwiYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci1pY29ucyBpY29uLXJvdW5kZWQtY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYWIgZmEtZ2l0aHViXCI+PC9pPiAxMzQxMVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRleHQ+ICovfVxyXG4gICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgey8qIDwvQ2FyZFRleHQ+ICovfVxyXG4gICAgICAgICAgICAgIHsvKiA8Q2FyZEZvb3Rlcj5cclxuICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cImZsb2F0LXJpZ2h0XCI+QWRkIG5ldzwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8L0NhcmRGb290ZXI+ICovfVxyXG4gICAgICAgICAgICA8L0NhcmRCb2R5PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDxDb2wgbWQ9XCI2XCIgbGc9XCI0XCIgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiaC0xMDAgbWItMlwiPlxyXG4gICAgICAgICAgICA8Q2FyZEJvZHk+XHJcbiAgICAgICAgICAgICAgPENhcmRUaXRsZSB0YWc9XCJoNFwiIGNsYXNzTmFtZT1cImhlYWRsaW5lLW1tXCI+XHJcbiAgICAgICAgICAgICAgICBQcm9qZWN0IFBvcnRmb2xpb1xyXG4gICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxyXG4gICAgICAgICAgICAgIHsvKiA8Q2FyZFRleHQ+ICovfVxyXG4gICAgICAgICAgICAgIDxSb3cgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPENvbCB4cz1cIlwiIGNsYXNzTmFtZT1cImQtaW5saW5lIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGFibGVDb250YWluZXIgLz5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICA8L0NhcmRCb2R5PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICAgIHsvKiA8Q29sIG1kPVwiNlwiIGxnPVwiNFwiIGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiaC0xMDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxDYXJkQm9keT5cclxuICAgICAgICAgICAgICAgIDxDYXJkVGl0bGUgdGFnPVwiaDRcIiBjbGFzc05hbWU9XCJoZWFkbGluZS1tbVwiPlxyXG4gICAgICAgICAgICAgICAgICBTdWJzY3JpcHRpb25zXHJcbiAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cclxuICAgICAgICAgICAgICAgIDxSb3cgY2xhc3NOYW1lPVwiYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgPENvbCBsZz1cIjZcIiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvdXRsaW5lIGNvbG9yPVwicHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwicHJpbWFyeVwiPjIxPC9CYWRnZT4mbmJzcDtQcmVtaXVtXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzbWFsbCBtbC0yIHRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWFycm93LXVwXCI+PC9pPiAyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCBsZz1cIjZcIiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvdXRsaW5lIGNvbG9yPVwic3VjY2Vzc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwic3VjY2Vzc1wiPjkwPC9CYWRnZT4mbmJzcDtFbnRlcnByaXNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzbWFsbCBtbC0yIHRleHQtc3VjY2Vzc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWFycm93LXVwXCI+PC9pPiA0M1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgbGc9XCI2XCIgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgb3V0bGluZSBjb2xvcj1cInNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwic2Vjb25kYXJ5XCI+NDU8L0JhZGdlPiZuYnNwO0ZyZWVcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInNtYWxsIG1sLTIgdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1hcnJvdy11cFwiPjwvaT4gMTFcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIGxnPVwiNlwiIGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIG91dGxpbmUgY29sb3I9XCJkYW5nZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cImRhbmdlclwiPjU1OTwvQmFkZ2U+Jm5ic3A7QmFzaWNcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInNtYWxsIG1sLTIgdGV4dC1kYW5nZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1hcnJvdy11cFwiPjwvaT4gMzJcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgPC9DYXJkQm9keT5cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgPC9Db2w+ICovfVxyXG4gICAgICAgIHsvKiA8Q29sIG1kPVwiNlwiIGxnPVwiNFwiIGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiaC0xMDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxDYXJkQm9keT5cclxuICAgICAgICAgICAgICAgIDxDYXJkVGl0bGUgdGFnPVwiaDRcIiBjbGFzc05hbWU9XCJoZWFkbGluZS1tbVwiPlxyXG4gICAgICAgICAgICAgICAgICBGaWxlcyBPdmVydmlld1xyXG4gICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8Um93IGNsYXNzTmFtZT1cImNsZWFyZml4XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgc209XCI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0IHRhZz1cInNwYW5cIiBjbGFzc05hbWU9XCJzbWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUHJvamVjdHNcclxuICAgICAgICAgICAgICAgICAgICA8L0NhcmRUZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhcyBmYS1icmllZmNhc2UgZmEtMXggdGV4dC1wcmltYXJ5XCI+PC9pPiZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC13ZWlnaHQtYm9sZCB0ZXh0LW11dGVkXCI+MjM0MTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgc209XCI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0IHRhZz1cInNwYW5cIiBjbGFzc05hbWU9XCJzbWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRG93bmxvYWRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYXMgZmEtY2xvdWQtZG93bmxvYWQtYWx0IGZhLTF4IHRleHQtc3VjY2Vzc1wiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC13ZWlnaHQtYm9sZCB0ZXh0LW11dGVkXCI+NDE0NDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgc209XCI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0IHRhZz1cInNwYW5cIiBjbGFzc05hbWU9XCJzbWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYXMgZmEtbGlzdCBmYS0xeCB0ZXh0LXdhcm5pbmdcIj48L2k+Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXdlaWdodC1ib2xkIHRleHQtbXV0ZWRcIj4zNDEwPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCBzbT1cIjRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZFRleHQgdGFnPVwic3BhblwiIGNsYXNzTmFtZT1cInNtYWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOZXdzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYXMgZmEtbmV3c3BhcGVyIGZhLTF4IHRleHQtZGFuZ2VyXCI+PC9pPiZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC13ZWlnaHQtYm9sZCB0ZXh0LW11dGVkXCI+NTM3Mjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgc209XCI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0IHRhZz1cInNwYW5cIiBjbGFzc05hbWU9XCJzbWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVXBsb2Fkc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZmFzIGZhLXVwbG9hZCBmYS0xeCB0ZXh0LWluZm9cIj48L2k+Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXdlaWdodC1ib2xkIHRleHQtbXV0ZWRcIj40MTQ0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCBzbT1cIjRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZFRleHQgdGFnPVwic3BhblwiIGNsYXNzTmFtZT1cInNtYWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBPcmRlcnNcclxuICAgICAgICAgICAgICAgICAgICA8L0NhcmRUZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhcyBmYS1zaG9wcGluZy1jYXJ0IGZhLTF4IHRleHQtcHJpbWFyeVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC13ZWlnaHQtYm9sZCB0ZXh0LW11dGVkXCI+MzQxMDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICA8L0NhcmRCb2R5PlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICA8L0NvbD4gKi99XHJcblxyXG4gICAgICAgIDxDb2wgbWQ9XCIxMlwiIGxnPVwiMTJcIiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJoLTEwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxDYXJkQm9keT5cclxuICAgICAgICAgICAgICA8Q2FyZFRpdGxlIHRhZz1cImg0XCIgY2xhc3NOYW1lPVwiaGVhZGxpbmUtbW1cIj5cclxuICAgICAgICAgICAgICAgIFJlY2VudCBBZGRpdGlvbnNcclxuICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cclxuXHJcbiAgICAgICAgICAgICAgey8qIDxDYXJkVGV4dD48L0NhcmRUZXh0PiAqL31cclxuICAgICAgICAgICAgICA8UHJvamVjdHNIb3Jpem9udGFsIC8+XHJcbiAgICAgICAgICAgICAgey8qIDxCdXR0b24+R28gc29tZXdoZXJlPC9CdXR0b24+ICovfVxyXG4gICAgICAgICAgICA8L0NhcmRCb2R5PlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICA8L1Jvdz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IFRhYmxlUGFnZSBmcm9tIFwiLi9UYWJsZVBhZ2VcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRhYmxlQ29udGFpbmVyKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICByZXR1cm4gPFRhYmxlUGFnZSAvPjtcclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IHsgQ29sLCBSb3csIFRhYmxlIH0gZnJvbSBcInJlYWN0c3RyYXBcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRhYmxlUGFnZSgpIHtcclxuICAvL2NvbnN0IHsgZGlzcGF0Y2gsIHN0b3JlTGF5b3V0IH0gPSBwcm9wcztcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGgxPjwvaDE+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyb1wiPlxyXG4gICAgICAgIDxSb3c+XHJcbiAgICAgICAgICB7LyogPENvbCB4cz1cIjZcIj5cclxuICAgICAgICAgICAgPGg0PkRlZmF1bHQ8L2g0PlxyXG4gICAgICAgICAgICA8VGFibGU+XHJcbiAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5GaXJzdCBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoPkxhc3QgTmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5Vc2VybmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4xPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPk1hcms8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+T3R0bzwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5AbWRvPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+SmFjb2I8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+VGhvcm50b248L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+QGZhdDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4zPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkxhcnJ5PC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPnRoZSBCaXJkPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkB0d2l0dGVyPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgIDwvQ29sPiAqL31cclxuICAgICAgICAgIHsvKiA8Q29sIHhzPVwiNlwiPlxyXG4gICAgICAgICAgICA8aDQ+SG92ZXI8L2g0PlxyXG4gICAgICAgICAgICA8VGFibGUgaG92ZXI+XHJcbiAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5GaXJzdCBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoPkxhc3QgTmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5Vc2VybmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4xPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPk1hcms8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+T3R0bzwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5AbWRvPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+SmFjb2I8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+VGhvcm50b248L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+QGZhdDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4zPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkxhcnJ5PC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPnRoZSBCaXJkPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkB0d2l0dGVyPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgIDwvQ29sPiAqL31cclxuICAgICAgICAgIDxDb2wgeHM9XCIxMlwiPlxyXG4gICAgICAgICAgICA8aDQ+PC9oND5cclxuICAgICAgICAgICAgPFRhYmxlIHN0cmlwZWQgaG92ZXI+XHJcbiAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5Qcm9qZWN0IE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+U3lzdGVtIFNpemU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+VXRpbGl0eTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4xPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPk1hdHJpeC1TeXN0ZW0gMUE8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+MjQwMCBrVyAoZGMpPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkNvbkVkPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+TWF0cml4LVN5c3RlbSAxQjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD41MTQxIGtXIChkYyk8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+Q29uRWQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwicm93XCI+MzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5NYXRyaXggLSBTeXN0ZW0gMkE8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+MjgwOCBrVyAoZGMpPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkNvbkVkPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgey8qIDxDb2wgeHM9XCI2XCI+XHJcbiAgICAgICAgICAgIDxoND5EYXJrPC9oND5cclxuICAgICAgICAgICAgPFRhYmxlIGRhcmsgaG92ZXI+XHJcbiAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5GaXJzdCBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoPkxhc3QgTmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5Vc2VybmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4xPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPk1hcms8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+T3R0bzwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5AbWRvPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPjI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+SmFjb2I8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+VGhvcm50b248L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+QGZhdDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj4zPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkxhcnJ5PC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPnRoZSBCaXJkPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPkB0d2l0dGVyPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgIDwvQ29sPiAqL31cclxuICAgICAgICA8L1Jvdz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiIsIi8vIE1lbnVzXHJcbmNvbnN0IE1FTlVTID0gW1xyXG4gIHtcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBhczogXCJhXCIsXHJcbiAgICBocmVmOiBcIi9kYXNoYm9hcmQvZGFzaGJvYXJkXCIsXHJcbiAgICBsYWJlbDogXCJEYXNoYm9hcmRcIixcclxuICAgIGljb246IFwiZmFzIGZhLWNoYXJ0LXBpZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJQcm9qZWN0c1wiLFxyXG4gICAgYXM6IFwiYVwiLFxyXG4gICAgaHJlZjogXCIvY2FyZC9wb3N0c1wiLFxyXG4gICAgbGFiZWw6IFwiUHJvamVjdHNcIixcclxuICAgIGljb246IFwiZmFzIGZhLWNsb25lXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIlN1YnNjcmliZXJzXCIsXHJcbiAgICBhczogXCJhXCIsXHJcbiAgICBocmVmOiBcIi9mb3JtL2J1dHRvbnNcIixcclxuICAgIGxhYmVsOiBcIlN1YnNjcmliZXJzXCIsXHJcbiAgICBpY29uOiBcImZhcyBmYS1idWxsc2V5ZVwiLFxyXG4gIH0sXHJcbiAgLy8ge1xyXG4gIC8vICAgbmFtZTogJ3RhYmxlcycsXHJcbiAgLy8gICBhczogJ2EnLFxyXG4gIC8vICAgaHJlZjogJy90YWJsZS90YWJsZXMnLFxyXG4gIC8vICAgbGFiZWw6ICdUYWJsZXMnLFxyXG4gIC8vICAgaWNvbjogJ2ZhcyBmYS1jb2x1bW5zJyxcclxuICAvLyB9LFxyXG4gIC8vIHtcclxuICAvLyAgIG5hbWU6ICd0eXBvZ3JhcGh5JyxcclxuICAvLyAgIGFzOiAnYScsXHJcbiAgLy8gICBocmVmOiAnL3BhZ2UvdHlwb2dyYXBoeScsXHJcbiAgLy8gICBsYWJlbDogJ1R5cG9ncmFwaHknLFxyXG4gIC8vICAgaWNvbjogJ2ZhcyBmYS1saXN0LXVsJyxcclxuICAvLyB9LFxyXG5dO1xyXG4vLyBTdWIgbWVudXNcclxuY29uc3QgU1VCTUVOVVMgPSBbXHJcbiAge1xyXG4gICAgbmFtZTogXCJBY2NvdW50XCIsXHJcbiAgICBhczogXCJhXCIsXHJcbiAgICBocmVmOiBcIi9jYXJkL2VtcGxveWVlc1wiLFxyXG4gICAgbGFiZWw6IFwiQWNjb3VudFwiLFxyXG4gICAgaWNvbjogXCJcIixcclxuICAgIC8vIH0sXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6ICdjYXJvdXNlbHMnLFxyXG4gICAgLy8gICBhczogJ2EnLFxyXG4gICAgLy8gICBocmVmOiAnL2Nhcm91c2VsL2Nhcm91c2VscycsXHJcbiAgICAvLyAgIGxhYmVsOiAnQ2Fyb3VzZWxzJyxcclxuICAgIC8vICAgaWNvbjogJycsXHJcbiAgICAvLyB9LFxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiAncGFnZXMnLFxyXG4gICAgLy8gICBhczogJ2EnLFxyXG4gICAgLy8gICBocmVmOiAnIycsXHJcbiAgICAvLyAgIGxhYmVsOiAnUGFnZXMnLFxyXG4gICAgLy8gICBpY29uOiAnJyxcclxuICAgIC8vICAgc3ViTGlua3M6IFtcclxuICAgIC8vICAgICB7XHJcbiAgICAvLyAgICAgICBuYW1lOiAncHJvZmlsZScsXHJcbiAgICAvLyAgICAgICBhczogJ2EnLFxyXG4gICAgLy8gICAgICAgaHJlZjogJy9wYWdlL3Byb2ZpbGUnLFxyXG4gICAgLy8gICAgICAgbGFiZWw6ICdQcm9maWxlJyxcclxuICAgIC8vICAgICAgIGljb246ICcnLFxyXG4gICAgLy8gICAgIH0sXHJcbiAgICAvLyAgICAge1xyXG4gICAgLy8gICAgICAgbmFtZTogJ3NldHRpbmcnLFxyXG4gICAgLy8gICAgICAgYXM6ICdhJyxcclxuICAgIC8vICAgICAgIGhyZWY6ICcvcGFnZS9zZXR0aW5nJyxcclxuICAgIC8vICAgICAgIGxhYmVsOiAnU2V0dGluZ3MnLFxyXG4gICAgLy8gICAgICAgaWNvbjogJycsXHJcbiAgICAvLyAgICAgfSxcclxuICAgIC8vICAgICB7XHJcbiAgICAvLyAgICAgICBuYW1lOiAnbG9naW4nLFxyXG4gICAgLy8gICAgICAgYXM6ICdhJyxcclxuICAgIC8vICAgICAgIGhyZWY6ICcvcGFnZS9sb2dpbicsXHJcbiAgICAvLyAgICAgICBsYWJlbDogJ0xvZ2luJyxcclxuICAgIC8vICAgICAgIGljb246ICcnLFxyXG4gICAgLy8gICAgIH0sXHJcbiAgICAvLyAgIF0sXHJcbiAgICAvLyB9LFxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiAnZm9ybXMnLFxyXG4gICAgLy8gICBhczogJ2EnLFxyXG4gICAgLy8gICBocmVmOiAnL2Zvcm0vZm9ybXMnLFxyXG4gICAgLy8gICBsYWJlbDogJ0Zvcm1zJyxcclxuICAgIC8vICAgaWNvbjogJycsXHJcbiAgICAvLyB9LFxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiAncGFnZXMnLFxyXG4gICAgLy8gICBhczogJ2EnLFxyXG4gICAgLy8gICBocmVmOiAnIycsXHJcbiAgICAvLyAgIGxhYmVsOiAnUGFnZXMnLFxyXG4gICAgLy8gICBpY29uOiAnJyxcclxuICAgIC8vICAgc3ViTGlua3M6IFtcclxuICAgIC8vICAgICB7XHJcbiAgICAvLyAgICAgICBuYW1lOiAncHJvZmlsZScsXHJcbiAgICAvLyAgICAgICBhczogJ2EnLFxyXG4gICAgLy8gICAgICAgaHJlZjogJy9wYWdlL3Byb2ZpbGUnLFxyXG4gICAgLy8gICAgICAgbGFiZWw6ICdQcm9maWxlJyxcclxuICAgIC8vICAgICAgIGljb246ICcnLFxyXG4gICAgLy8gICAgIH0sXHJcbiAgICAvLyAgICAge1xyXG4gICAgLy8gICAgICAgbmFtZTogJ3NldHRpbmcnLFxyXG4gICAgLy8gICAgICAgYXM6ICdhJyxcclxuICAgIC8vICAgICAgIGhyZWY6ICcvcGFnZS9zZXR0aW5nJyxcclxuICAgIC8vICAgICAgIGxhYmVsOiAnU2V0dGluZ3MnLFxyXG4gICAgLy8gICAgICAgaWNvbjogJycsXHJcbiAgICAvLyAgICAgfSxcclxuICAgIC8vICAgICB7XHJcbiAgICAvLyAgICAgICBuYW1lOiAnbG9naW4nLFxyXG4gICAgLy8gICAgICAgYXM6ICdhJyxcclxuICAgIC8vICAgICAgIGhyZWY6ICcvcGFnZS9sb2dpbicsXHJcbiAgICAvLyAgICAgICBsYWJlbDogJ0xvZ2luJyxcclxuICAgIC8vICAgICAgIGljb246ICcnLFxyXG4gICAgLy8gICAgIH0sXHJcbiAgICAvLyAgIF0sXHJcbiAgfSxcclxuXTtcclxuXHJcbmV4cG9ydCB7IE1FTlVTLCBTVUJNRU5VUyB9O1xyXG4iLCJjb25zdCBUSEVNRSA9IHtcclxuICB0aXRsZTogXCJDREcgVHJhY2tpbmdcIixcclxuICBkZXNjcmlwdGlvbjogXCJNYXRyaXggQ0RHIFRyYWNraW5nXCIsXHJcbn07XHJcblxyXG5leHBvcnQgeyBUSEVNRSB9O1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgbWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCB7IENvbnRhaW5lciwgUm93LCBDb2wgfSBmcm9tIFwicmVhY3RzdHJhcFwiO1xyXG5pbXBvcnQgTmF2TGVmdCBmcm9tIFwiLi9uYXYvTmF2TGVmdFwiO1xyXG5pbXBvcnQgTmF2QmFyIGZyb20gXCIuL25hdi9OYXZCYXJcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1haW5MYXlvdXQobWFpblByb3BzKSB7XHJcbiAgY29uc3QgeyBjaGlsZHJlbiwgZGlzcGF0Y2gsIHN0b3JlTGF5b3V0LCBhY3RpdmVMaW5rIH0gPSBtYWluUHJvcHM7XHJcblxyXG4gIC8qIGxheW91dCB2YXJzICovXHJcbiAgY29uc3Qgd2lkZU5hdiA9IHsgd2lkdGg6IFwiMjQwcHhcIiB9O1xyXG4gIGNvbnN0IHdpZGVDb250ZW50ID0geyBtYXJnaW5MZWZ0OiBcIjI0MHB4XCIgfTtcclxuXHJcbiAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNUb2dnbGVkLCBzZXRJc1RvZ2dsZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc1dpZGVOYXYsIHNldElzV2lkZU5hdl0gPSB1c2VTdGF0ZSh7IC4uLndpZGVOYXYgfSk7XHJcbiAgY29uc3QgW2lzV2lkZUNvbnRlbnQsIHNldElzV2lkZUNvbnRlbnRdID0gdXNlU3RhdGUoeyAuLi53aWRlQ29udGVudCB9KTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlID0gKCkgPT4gc2V0SXNPcGVuKCFpc09wZW4pO1xyXG4gIGNvbnN0IHRvZ2dsZUxlZnQgPSAoKSA9PiB7XHJcbiAgICBzZXRJc1RvZ2dsZWQoIWlzVG9nZ2xlZCk7XHJcbiAgICBpZiAoc3RvcmVMYXlvdXQudG9nZ2xlKSB7XHJcbiAgICAgIHNldElzV2lkZU5hdih7IC4uLndpZGVOYXYgfSk7XHJcbiAgICAgIHNldElzV2lkZUNvbnRlbnQoeyAuLi53aWRlQ29udGVudCB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldElzV2lkZU5hdih7IHdpZHRoOiAwLCBwYWRkaW5nOiAwIH0pO1xyXG4gICAgICBzZXRJc1dpZGVDb250ZW50KHsgbWFyZ2luTGVmdDogMCB9KTtcclxuICAgIH1cclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogQUNUSU9OX1RZUEVTLkxBWU9VVC5UT0dHTEUsXHJcbiAgICAgIHRvZ2dsZTogaXNUb2dnbGVkLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxOYXZCYXIgLz5cclxuICAgICAgPENvbnRhaW5lciBmbHVpZCBjbGFzc05hbWU9XCJ3cmFwcGVyXCI+XHJcbiAgICAgICAgPFJvdz5cclxuICAgICAgICAgIDxDb2wgY2xhc3NOYW1lPVwid3JhcHBlci1sZWZ0XCIgc3R5bGU9e2lzV2lkZU5hdn0+XHJcbiAgICAgICAgICAgIDxOYXZMZWZ0IGFjdGl2ZUxpbms9e2FjdGl2ZUxpbmt9IC8+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgY2xhc3NOYW1lPVwid3JhcHBlci1jb250ZW50XCIgc3R5bGU9e2lzV2lkZUNvbnRlbnR9PlxyXG4gICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICA8L1Jvdz5cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgIHsvKiA8Rm9vdGVyIC8+ICovfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iLCJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBwcm9wVHlwZXMgZnJvbSBcInByb3AtdHlwZXNcIjtcclxuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xyXG5pbXBvcnQgeyBUSEVNRSB9IGZyb20gXCIuLi8uLi9jb25zdGFudHMvdmFyc1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGVhZERlZmF1bHQoe1xyXG4gIHRpdGxlLFxyXG4gIGRlc2NyaXB0aW9uLFxyXG4gIGtleXdvcmQsXHJcbiAgb2dUaXRsZSxcclxuICBvZ0Rlc2NyaXB0aW9uLFxyXG4gIG9nSW1hZ2VVcmwsXHJcbiAgb2dJbWFnZUFsdCxcclxuICBvZ1VybCxcclxufSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8SGVhZD5cclxuICAgICAgPHRpdGxlPlxyXG4gICAgICAgIHt0aXRsZX0gfCB7VEhFTUUudGl0bGV9XHJcbiAgICAgIDwvdGl0bGU+XHJcblxyXG4gICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XHJcblxyXG4gICAgICB7LyogTUVUQSBTRU8gKi99XHJcbiAgICAgIDxtZXRhIG5hbWU9XCJ0aXRsZVwiIGNvbnRlbnQ9e3RpdGxlfSAvPlxyXG4gICAgICA8bWV0YSBuYW1lPVwiZGVzY3JpcHRpb25cIiBjb250ZW50PXtkZXNjcmlwdGlvbn0gLz5cclxuICAgICAgPG1ldGEgbmFtZT1cImtleXdvcmRzXCIgY29udGVudD17a2V5d29yZH0gLz5cclxuXHJcbiAgICAgIHsvKiBNRVRBIE9HICovfVxyXG4gICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOnRpdGxlXCIgY29udGVudD17b2dUaXRsZX0gLz5cclxuICAgICAgPG1ldGEgcHJvcGVydHk9XCJvZzpkZXNjcmlwdGlvblwiIGNvbnRlbnQ9e29nRGVzY3JpcHRpb259IC8+XHJcbiAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6dXJsXCIgY29udGVudD17b2dVcmx9IC8+XHJcbiAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2VcIiBjb250ZW50PXtvZ0ltYWdlVXJsfSAvPlxyXG4gICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOmltYWdlOnVybFwiIGNvbnRlbnQ9e29nSW1hZ2VVcmx9IC8+XHJcbiAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2U6YWx0XCIgY29udGVudD17b2dJbWFnZUFsdH0gLz5cclxuICAgICAgPG1ldGEgcHJvcGVydHk9XCJvZzppbWFnZTp0eXBlXCIgY29udGVudD1cImltYWdlL2pwZ1wiIC8+XHJcbiAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2U6d2lkdGhcIiBjb250ZW50PVwiMTIwMFwiIC8+XHJcbiAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2U6aGVpZ2h0XCIgY29udGVudD1cIjYyOFwiIC8+XHJcbiAgICA8L0hlYWQ+XHJcbiAgKTtcclxufVxyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQ29sbGFwc2UsXHJcbiAgTmF2YmFyLFxyXG4gIE5hdmJhclRvZ2dsZXIsXHJcbiAgTmF2YmFyQnJhbmQsXHJcbiAgTmF2LFxyXG4gIE5hdkl0ZW0sXHJcbiAgTmF2TGluayxcclxuICBVbmNvbnRyb2xsZWREcm9wZG93bixcclxuICBEcm9wZG93blRvZ2dsZSxcclxuICBEcm9wZG93bk1lbnUsXHJcbiAgRHJvcGRvd25JdGVtLFxyXG4gIE5hdmJhclRleHQsXHJcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5hdkJhcih7XHJcbiAgLyogc3RhdGUgdmFycyAqL1xyXG4gIGlzT3BlbixcclxuICBpc1RvZ2dsZWQsXHJcbiAgLyogdG9nZ2xlcyAqL1xyXG4gIHRvZ2dsZSxcclxuICB0b2dnbGVMZWZ0LFxyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgIDxOYXZiYXIgY29sb3I9XCJiZy1pbmZvXCIgZGFyayBleHBhbmQ9XCJzbVwiIGZpeGVkPVwidG9wXCI+XHJcbiAgICAgICAgPE5hdmJhckJyYW5kIGhyZWY9XCIvXCI+XHJcbiAgICAgICAgICA8aW1nIHNyYz1cIi9NTS5zdmdcIiBhbHQ9XCJMb2dvXCIgY2xhc3NOYW1lPVwiXCIgaGVpZ2h0PVwiODBcIiB3aWR0aD1cIjEwMFwiIC8+XHJcbiAgICAgICAgPC9OYXZiYXJCcmFuZD5cclxuICAgICAgICA8TmF2YmFyVG9nZ2xlciBvbkNsaWNrPXt0b2dnbGV9IGNvbG9yPVwiZGFya1wiIC8+XHJcbiAgICAgICAgPENvbGxhcHNlIGlzT3Blbj17aXNPcGVufSBuYXZiYXI+XHJcbiAgICAgICAgICA8TmF2IGNsYXNzTmFtZT1cIm1yLWF1dG9cIiBuYXZiYXI+XHJcbiAgICAgICAgICAgIHsvKiAgPE5hdkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImQtbm9uZSBkLXNtLWJsb2NrXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlTGVmdH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmYXMgZmEtY2FyZXQtc3F1YXJlLSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpc1RvZ2dsZWQgPyAnbGVmdCcgOiAncmlnaHQnXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID48L2k+XHJcbiAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgPC9OYXZJdGVtPiAqL31cclxuICAgICAgICAgICAgey8qIDxOYXZJdGVtPlxyXG4gICAgICAgICAgICAgICAgPE5hdkxpbmsgaHJlZj1cIi9wYWdlL3R5cG9ncmFwaHlcIj48L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgPC9OYXZJdGVtPiAqL31cclxuICAgICAgICAgICAgPFVuY29udHJvbGxlZERyb3Bkb3duIG5hdiBpbk5hdmJhcj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25Ub2dnbGUgbmF2IGNhcmV0PjwvRHJvcGRvd25Ub2dnbGU+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudSByaWdodD5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93bkl0ZW0gdGFnPVwiZGl2XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIGhyZWY9XCIvY2FyZC9wb3N0c1wiIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENhcmRzXHJcbiAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICAgICAgICAgIDwvRHJvcGRvd25JdGVtPlxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duSXRlbSB0YWc9XCJkaXZcIj5cclxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmsgaHJlZj1cIi90YWJsZS90YWJsZXNcIiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICBUYWJsZXNcclxuICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8RHJvcGRvd25JdGVtIHRhZz1cImRpdlwiPlxyXG4gICAgICAgICAgICAgICAgICA8TmF2TGluayBocmVmPVwiL2Zvcm0vYnV0dG9uc1wiIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEJ1dHRvbnNcclxuICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bkl0ZW0+XHJcbiAgICAgICAgICAgICAgICB7LyogPERyb3Bkb3duSXRlbSBkaXZpZGVyIC8+ICovfVxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duSXRlbSB0YWc9XCJkaXZcIj5cclxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmsgaHJlZj1cIi9mb3JtL2Zvcm1zXCIgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRm9ybXNcclxuICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnU+XHJcbiAgICAgICAgICAgIDwvVW5jb250cm9sbGVkRHJvcGRvd24+XHJcbiAgICAgICAgICA8L05hdj5cclxuICAgICAgICAgIHsvKiAgPFVuY29udHJvbGxlZERyb3Bkb3duIGluTmF2YmFyPlxyXG4gICAgICAgICAgICAgIDxEcm9wZG93blRvZ2dsZSBjYXJldCBuYXYgY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnlcIj4gKi99XHJcbiAgICAgICAgICA8TmF2YmFyVGV4dCBjbGFzc05hbWU9XCJhbGlnbi1zZWxmLWNlbnRlciB0ZXh0LWxlZnQgZm9udC13ZWlnaHQtYm9sZFwiPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiL2ltYWdlcy9wcm9maWxlMi5qcGdcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLWNpcmNsZSBpbWctNDIgaW1nLWZsdWlkIG1yLTFcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICBMb2dvdXRcclxuICAgICAgICAgIDwvTmF2YmFyVGV4dD5cclxuICAgICAgICAgIHsvKiAgPC9Ecm9wZG93blRvZ2dsZT5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51PlxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duSXRlbSB0YWc9XCJkaXZcIj5cclxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmsgaHJlZj1cIi9wYWdlL3Byb2ZpbGVcIiBjbGFzc05hbWU9XCJ0ZXh0LWRhcmtcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdXNlclwiPjwvaT4gUHJvZmlsZVxyXG4gICAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duSXRlbT5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93bkl0ZW0gdGFnPVwiZGl2XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIGhyZWY9XCIvcGFnZS9zZXR0aW5nXCIgY2xhc3NOYW1lPVwidGV4dC1kYXJrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNvZ1wiPjwvaT4gU2V0dGluZ1xyXG4gICAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duSXRlbT5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93bkl0ZW0gdGFnPVwiZGl2XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIGhyZWY9XCIvcGFnZS9sb2dpblwiIGNsYXNzTmFtZT1cInRleHQtZGFya1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1ob21lXCI+PC9pPiBMb2dvdXRcclxuICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnU+XHJcbiAgICAgICAgICAgIDwvVW5jb250cm9sbGVkRHJvcGRvd24+XHJcbiAgICAgICAgICA8L0NvbGxhcHNlPiAqL31cclxuICAgICAgICA8L0NvbGxhcHNlPlxyXG4gICAgICA8L05hdmJhcj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBMaXN0R3JvdXAsXHJcbiAgTGlzdEdyb3VwSXRlbSxcclxuICBOYXYsXHJcbiAgTmF2SXRlbSxcclxuICBOYXZMaW5rLFxyXG4gIFVuY29udHJvbGxlZENvbGxhcHNlLFxyXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XHJcblxyXG5pbXBvcnQgeyBNRU5VUywgU1VCTUVOVVMgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL21lbnVzXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOYXZMZWZ0KHByb3BzKSB7XHJcbiAgY29uc3QgeyBhY3RpdmVMaW5rIH0gPSBwcm9wcztcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGg0IGNsYXNzTmFtZT1cImhlYWRsaW5lXCI+RGFzaGJvYXJkPC9oND5cclxuICAgICAgPGRpdiBjbGFzc05hbWU+XHJcbiAgICAgICAgPExpc3RHcm91cCBmbHVzaCBjbGFzc05hbWU9XCJsaXN0LWdyb3VwLW5hdi1sZWZ0XCIgdGFnPVwiZGl2XCI+XHJcbiAgICAgICAgICB7TUVOVVMubWFwKChpdGVtLCBrKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlTGluayA9PT0gaXRlbS5uYW1lID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxMaXN0R3JvdXBJdGVtXHJcbiAgICAgICAgICAgICAgICBrZXk9e2BsJHtrfWB9XHJcbiAgICAgICAgICAgICAgICBhY3RpdmU9e2lzQWN0aXZlfVxyXG4gICAgICAgICAgICAgICAgdGFnPXtpdGVtLmFzfVxyXG4gICAgICAgICAgICAgICAgaHJlZj17XCIjXCJ9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2l0ZW0uaWNvbiAmJiA8aSBjbGFzc05hbWU9e2l0ZW0uaWNvbn0+PC9pPn0ge2l0ZW0ubGFiZWx9XHJcbiAgICAgICAgICAgICAgPC9MaXN0R3JvdXBJdGVtPlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfSl9XHJcbiAgICAgICAgPC9MaXN0R3JvdXA+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8aDQgY2xhc3NOYW1lPVwiaGVhZGxpbmVcIj5TZXR0aW5nczwvaDQ+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPExpc3RHcm91cCBmbHVzaCBjbGFzc05hbWU9XCJsaXN0LWdyb3VwLW5hdi1sZWZ0XCIgdGFnPVwiZGl2XCI+XHJcbiAgICAgICAgICB7U1VCTUVOVVMubWFwKChzdWJJdGVtLCBrKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlTGluayA9PT0gc3ViSXRlbS5uYW1lID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgICAgICBjb25zdCBhY3RpdmVNZW51cyA9IGFjdGl2ZUxpbmsgJiYgYWN0aXZlTGluay5zcGxpdChcIi5cIik7XHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgKCFzdWJJdGVtLnN1YkxpbmtzICYmIChcclxuICAgICAgICAgICAgICAgIDxMaXN0R3JvdXBJdGVtXHJcbiAgICAgICAgICAgICAgICAgIGtleT17YGske2t9YH1cclxuICAgICAgICAgICAgICAgICAgYWN0aXZlPXtpc0FjdGl2ZX1cclxuICAgICAgICAgICAgICAgICAgdGFnPXtzdWJJdGVtLmFzfVxyXG4gICAgICAgICAgICAgICAgICBocmVmPXtcIiNcIn1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3N1Ykl0ZW0uaWNvbiAmJiA8aSBjbGFzc05hbWU9e3N1Ykl0ZW0uaWNvbn0+PC9pPn0mbmJzcDtcclxuICAgICAgICAgICAgICAgICAge3N1Ykl0ZW0ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICA8L0xpc3RHcm91cEl0ZW0+XHJcbiAgICAgICAgICAgICAgKSkgfHwgKFxyXG4gICAgICAgICAgICAgICAgPExpc3RHcm91cEl0ZW1cclxuICAgICAgICAgICAgICAgICAga2V5PXtga3Mke2t9YH1cclxuICAgICAgICAgICAgICAgICAgdGFnPVwiZGl2XCJcclxuICAgICAgICAgICAgICAgICAgLyogYWN0aXZlPXthY3RpdmVNZW51c1swXSA/IHRydWUgOiBmYWxzZX0gKi9cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICBocmVmPXtzdWJJdGVtLmhyZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZHJvcGRvd24tdG9nZ2xlXCJcclxuICAgICAgICAgICAgICAgICAgICBpZD17YHRvZ2dsZUNvbGxhcHNlci0ke2t9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzdWJJdGVtLmljb24gJiYgPGkgY2xhc3NOYW1lPXtzdWJJdGVtLmljb259PjwvaT59Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAge3N1Ykl0ZW0ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPFVuY29udHJvbGxlZENvbGxhcHNlXHJcbiAgICAgICAgICAgICAgICAgICAgdG9nZ2xlcj17YHRvZ2dsZUNvbGxhcHNlci0ke2t9YH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBpc09wZW49e2FjdGl2ZU1lbnVzWzFdID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPE5hdiB2ZXJ0aWNhbCBjbGFzc05hbWU9XCJtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3ViSXRlbS5zdWJMaW5rcy5tYXAoKHN1YnMsIGwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTdWJBY3RpdmUgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZU1lbnVzICYmIGFjdGl2ZU1lbnVzWzFdID09PSBzdWJzLm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkl0ZW0ga2V5PXtgbCR7bH1gfSBhY3RpdmU9e2lzU3ViQWN0aXZlID09PSB0cnVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rIGhyZWY9e3N1YnMuaHJlZn0+e3N1YnMubGFiZWx9PC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTmF2PlxyXG4gICAgICAgICAgICAgICAgICA8L1VuY29udHJvbGxlZENvbGxhcHNlPlxyXG4gICAgICAgICAgICAgICAgPC9MaXN0R3JvdXBJdGVtPlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvTGlzdEdyb3VwPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IEhlYWREZWZhdWx0IGZyb20gXCJAL2xheW91dC9oZWFkL0hlYWREZWZhdWx0XCI7XHJcbi8vaW1wb3J0IFRhYmxlUGFnZSBmcm9tIFwiQC9jb21wb25lbnRzL3RhYmxlL1RhYmxlUGFnZVwiO1xyXG5pbXBvcnQgRGFzaGJvYXJkQ29udGFpbmVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29udGFpbmVyL2Rhc2hib2FyZC9EYXNoYm9hcmRDb250YWluZXJcIjtcclxuaW1wb3J0IE1haW5MYXlvdXQgZnJvbSBcIkAvbGF5b3V0L01haW5MYXlvdXRcIjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZGFzaGJvYXJkX2FkbWluKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8TWFpbkxheW91dD5cclxuICAgICAgICA8SGVhZERlZmF1bHQgdGl0bGU9XCJNYXRyaXggQ0RHXCIgZGVzY3JpcHRpb249XCJBZG1pbiBEYXNoYm9hcmRcIiAvPlxyXG4gICAgICAgIDxEYXNoYm9hcmRDb250YWluZXIgLz5cclxuICAgICAgPC9NYWluTGF5b3V0PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInByb3AtdHlwZXNcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1jaGFydGpzLTJcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXJlZHV4XCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0c3RyYXBcIik7OyJdLCJzb3VyY2VSb290IjoiIn0=