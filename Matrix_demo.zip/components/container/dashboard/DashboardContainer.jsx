import DashboardPage from "./DashboardPage";
export default function DashboardContainer() {
  return (
    <>
      <DashboardPage />
    </>
  );
}
