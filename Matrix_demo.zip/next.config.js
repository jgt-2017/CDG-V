const withSass = require("@zeit/next-sass");
module.exports = withSass({
  cssLoaderOptions: {
    importLoaders: 2,
  },
});

module.exports = {
  env: {
    mongodburl:
      "mongodb+srv://Joy:charvi17@cluster0.knmqh.mongodb.net/projectRecord?retryWrites=true&w=majority",
  },
};
