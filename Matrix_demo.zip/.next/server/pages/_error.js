(function() {
var exports = {};
exports.id = "pages/_error";
exports.ids = ["pages/_error"];
exports.modules = {

/***/ "./node_modules/next/dist/pages/_error.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/pages/_error.js ***!
  \************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

const statusCodes = {
  400: 'Bad Request',
  404: 'This page could not be found',
  405: 'Method Not Allowed',
  500: 'Internal Server Error'
};

function _getInitialProps({
  res,
  err
}) {
  const statusCode = res && res.statusCode ? res.statusCode : err ? err.statusCode : 404;
  return {
    statusCode
  };
}
/**
* `Error` component used for handling errors.
*/


class Error extends _react.default.Component {
  render() {
    const {
      statusCode
    } = this.props;
    const title = this.props.title || statusCodes[statusCode] || 'An unexpected error has occurred';
    return /*#__PURE__*/_react.default.createElement("div", {
      style: styles.error
    }, /*#__PURE__*/_react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("title", null, statusCode ? `${statusCode}: ${title}` : 'Application error: a client-side exception has occurred')), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("style", {
      dangerouslySetInnerHTML: {
        __html: 'body { margin: 0 }'
      }
    }), statusCode ? /*#__PURE__*/_react.default.createElement("h1", {
      style: styles.h1
    }, statusCode) : null, /*#__PURE__*/_react.default.createElement("div", {
      style: styles.desc
    }, /*#__PURE__*/_react.default.createElement("h2", {
      style: styles.h2
    }, this.props.title || statusCode ? title : /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, "Application error: a client-side exception has occurred (", /*#__PURE__*/_react.default.createElement("a", {
      href: "https://nextjs.org/docs/messages/client-side-exception-occurred"
    }, "developer guidance"), ")"), "."))));
  }

}

exports.default = Error;
Error.displayName = 'ErrorPage';
Error.getInitialProps = _getInitialProps;
Error.origGetInitialProps = _getInitialProps;
const styles = {
  error: {
    color: '#000',
    background: '#fff',
    fontFamily: '-apple-system, BlinkMacSystemFont, Roboto, "Segoe UI", "Fira Sans", Avenir, "Helvetica Neue", "Lucida Grande", sans-serif',
    height: '100vh',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center'
  },
  desc: {
    display: 'inline-block',
    textAlign: 'left',
    lineHeight: '49px',
    height: '49px',
    verticalAlign: 'middle'
  },
  h1: {
    display: 'inline-block',
    borderRight: '1px solid rgba(0, 0, 0,.3)',
    margin: 0,
    marginRight: '20px',
    padding: '10px 23px 10px 0',
    fontSize: '24px',
    fontWeight: 500,
    verticalAlign: 'top'
  },
  h2: {
    fontSize: '14px',
    fontWeight: 'normal',
    lineHeight: 'inherit',
    margin: 0,
    padding: 0
  }
};

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \****************************************************************************************/
/***/ (function(module) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./node_modules/next/dist/pages/_error.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtcmVhY3RzdHJhcC8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvcGFnZXMvX2Vycm9yLmpzIiwid2VicGFjazovL25leHRqcy1yZWFjdHN0cmFwLy4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovL25leHRqcy1yZWFjdHN0cmFwL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIiLCJ3ZWJwYWNrOi8vbmV4dGpzLXJlYWN0c3RyYXAvZXh0ZXJuYWwgXCJyZWFjdFwiIl0sIm5hbWVzIjpbIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiZXhwb3J0cyIsIl9yZWFjdCIsIl9oZWFkIiwic3RhdHVzQ29kZXMiLCJfZ2V0SW5pdGlhbFByb3BzIiwicmVzIiwiZXJyIiwic3RhdHVzQ29kZSIsIkVycm9yIiwiZGVmYXVsdCIsIkNvbXBvbmVudCIsInJlbmRlciIsInByb3BzIiwidGl0bGUiLCJjcmVhdGVFbGVtZW50Iiwic3R5bGUiLCJzdHlsZXMiLCJlcnJvciIsImRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIiwiX19odG1sIiwiaDEiLCJkZXNjIiwiaDIiLCJGcmFnbWVudCIsImhyZWYiLCJkaXNwbGF5TmFtZSIsImdldEluaXRpYWxQcm9wcyIsIm9yaWdHZXRJbml0aWFsUHJvcHMiLCJjb2xvciIsImJhY2tncm91bmQiLCJmb250RmFtaWx5IiwiaGVpZ2h0IiwidGV4dEFsaWduIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJsaW5lSGVpZ2h0IiwidmVydGljYWxBbGlnbiIsImJvcmRlclJpZ2h0IiwibWFyZ2luIiwibWFyZ2luUmlnaHQiLCJwYWRkaW5nIiwiZm9udFNpemUiLCJmb250V2VpZ2h0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQWE7O0FBQUEsSUFBSUEsc0JBQXNCLEdBQUNDLG1CQUFPLENBQUMsc0lBQUQsQ0FBbEM7O0FBQW1GQyxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsZUFBQSxHQUFnQixLQUFLLENBQXJCOztBQUF1QixJQUFJQyxNQUFNLEdBQUNILHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBakM7O0FBQW9ELElBQUlHLEtBQUssR0FBQ0osc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsd0RBQUQsQ0FBUixDQUFoQzs7QUFBcUUsTUFBTUksV0FBVyxHQUFDO0FBQUMsT0FBSSxhQUFMO0FBQW1CLE9BQUksOEJBQXZCO0FBQXNELE9BQUksb0JBQTFEO0FBQStFLE9BQUk7QUFBbkYsQ0FBbEI7O0FBQThILFNBQVNDLGdCQUFULENBQTBCO0FBQUNDLEtBQUQ7QUFBS0M7QUFBTCxDQUExQixFQUFvQztBQUFDLFFBQU1DLFVBQVUsR0FBQ0YsR0FBRyxJQUFFQSxHQUFHLENBQUNFLFVBQVQsR0FBb0JGLEdBQUcsQ0FBQ0UsVUFBeEIsR0FBbUNELEdBQUcsR0FBQ0EsR0FBRyxDQUFDQyxVQUFMLEdBQWdCLEdBQXZFO0FBQTJFLFNBQU07QUFBQ0E7QUFBRCxHQUFOO0FBQW9CO0FBQUE7QUFDMWdCO0FBQ0E7OztBQUFHLE1BQU1DLEtBQU4sU0FBb0JQLE1BQU0sQ0FBQ1EsT0FBUCxDQUFlQyxTQUFuQyxDQUE0QztBQUFDQyxRQUFNLEdBQUU7QUFBQyxVQUFLO0FBQUNKO0FBQUQsUUFBYSxLQUFLSyxLQUF2QjtBQUE2QixVQUFNQyxLQUFLLEdBQUMsS0FBS0QsS0FBTCxDQUFXQyxLQUFYLElBQWtCVixXQUFXLENBQUNJLFVBQUQsQ0FBN0IsSUFBMkMsa0NBQXZEO0FBQTBGLFdBQU0sYUFBYU4sTUFBTSxDQUFDUSxPQUFQLENBQWVLLGFBQWYsQ0FBNkIsS0FBN0IsRUFBbUM7QUFBQ0MsV0FBSyxFQUFDQyxNQUFNLENBQUNDO0FBQWQsS0FBbkMsRUFBd0QsYUFBYWhCLE1BQU0sQ0FBQ1EsT0FBUCxDQUFlSyxhQUFmLENBQTZCWixLQUFLLENBQUNPLE9BQW5DLEVBQTJDLElBQTNDLEVBQWdELGFBQWFSLE1BQU0sQ0FBQ1EsT0FBUCxDQUFlSyxhQUFmLENBQTZCLE9BQTdCLEVBQXFDLElBQXJDLEVBQTBDUCxVQUFVLEdBQUUsR0FBRUEsVUFBVyxLQUFJTSxLQUFNLEVBQXpCLEdBQTJCLHlEQUEvRSxDQUE3RCxDQUFyRSxFQUE2USxhQUFhWixNQUFNLENBQUNRLE9BQVAsQ0FBZUssYUFBZixDQUE2QixLQUE3QixFQUFtQyxJQUFuQyxFQUF3QyxhQUFhYixNQUFNLENBQUNRLE9BQVAsQ0FBZUssYUFBZixDQUE2QixPQUE3QixFQUFxQztBQUFDSSw2QkFBdUIsRUFBQztBQUFDQyxjQUFNLEVBQUM7QUFBUjtBQUF6QixLQUFyQyxDQUFyRCxFQUFtSlosVUFBVSxHQUFDLGFBQWFOLE1BQU0sQ0FBQ1EsT0FBUCxDQUFlSyxhQUFmLENBQTZCLElBQTdCLEVBQWtDO0FBQUNDLFdBQUssRUFBQ0MsTUFBTSxDQUFDSTtBQUFkLEtBQWxDLEVBQW9EYixVQUFwRCxDQUFkLEdBQThFLElBQTNPLEVBQWdQLGFBQWFOLE1BQU0sQ0FBQ1EsT0FBUCxDQUFlSyxhQUFmLENBQTZCLEtBQTdCLEVBQW1DO0FBQUNDLFdBQUssRUFBQ0MsTUFBTSxDQUFDSztBQUFkLEtBQW5DLEVBQXVELGFBQWFwQixNQUFNLENBQUNRLE9BQVAsQ0FBZUssYUFBZixDQUE2QixJQUE3QixFQUFrQztBQUFDQyxXQUFLLEVBQUNDLE1BQU0sQ0FBQ007QUFBZCxLQUFsQyxFQUFvRCxLQUFLVixLQUFMLENBQVdDLEtBQVgsSUFBa0JOLFVBQWxCLEdBQTZCTSxLQUE3QixHQUFtQyxhQUFhWixNQUFNLENBQUNRLE9BQVAsQ0FBZUssYUFBZixDQUE2QmIsTUFBTSxDQUFDUSxPQUFQLENBQWVjLFFBQTVDLEVBQXFELElBQXJELEVBQTBELDJEQUExRCxFQUFzSCxhQUFhdEIsTUFBTSxDQUFDUSxPQUFQLENBQWVLLGFBQWYsQ0FBNkIsR0FBN0IsRUFBaUM7QUFBQ1UsVUFBSSxFQUFDO0FBQU4sS0FBakMsRUFBMEcsb0JBQTFHLENBQW5JLEVBQW1RLEdBQW5RLENBQXBHLEVBQTRXLEdBQTVXLENBQXBFLENBQTdQLENBQTFSLENBQW5CO0FBQW0rQjs7QUFBcG1DOztBQUFxbUN4QixlQUFBLEdBQWdCUSxLQUFoQjtBQUFzQkEsS0FBSyxDQUFDaUIsV0FBTixHQUFrQixXQUFsQjtBQUE4QmpCLEtBQUssQ0FBQ2tCLGVBQU4sR0FBc0J0QixnQkFBdEI7QUFBdUNJLEtBQUssQ0FBQ21CLG1CQUFOLEdBQTBCdkIsZ0JBQTFCO0FBQTJDLE1BQU1ZLE1BQU0sR0FBQztBQUFDQyxPQUFLLEVBQUM7QUFBQ1csU0FBSyxFQUFDLE1BQVA7QUFBY0MsY0FBVSxFQUFDLE1BQXpCO0FBQWdDQyxjQUFVLEVBQUMsMkhBQTNDO0FBQXVLQyxVQUFNLEVBQUMsT0FBOUs7QUFBc0xDLGFBQVMsRUFBQyxRQUFoTTtBQUF5TUMsV0FBTyxFQUFDLE1BQWpOO0FBQXdOQyxpQkFBYSxFQUFDLFFBQXRPO0FBQStPQyxjQUFVLEVBQUMsUUFBMVA7QUFBbVFDLGtCQUFjLEVBQUM7QUFBbFIsR0FBUDtBQUFtU2YsTUFBSSxFQUFDO0FBQUNZLFdBQU8sRUFBQyxjQUFUO0FBQXdCRCxhQUFTLEVBQUMsTUFBbEM7QUFBeUNLLGNBQVUsRUFBQyxNQUFwRDtBQUEyRE4sVUFBTSxFQUFDLE1BQWxFO0FBQXlFTyxpQkFBYSxFQUFDO0FBQXZGLEdBQXhTO0FBQXlZbEIsSUFBRSxFQUFDO0FBQUNhLFdBQU8sRUFBQyxjQUFUO0FBQXdCTSxlQUFXLEVBQUMsNEJBQXBDO0FBQWlFQyxVQUFNLEVBQUMsQ0FBeEU7QUFBMEVDLGVBQVcsRUFBQyxNQUF0RjtBQUE2RkMsV0FBTyxFQUFDLGtCQUFyRztBQUF3SEMsWUFBUSxFQUFDLE1BQWpJO0FBQXdJQyxjQUFVLEVBQUMsR0FBbko7QUFBdUpOLGlCQUFhLEVBQUM7QUFBckssR0FBNVk7QUFBd2pCaEIsSUFBRSxFQUFDO0FBQUNxQixZQUFRLEVBQUMsTUFBVjtBQUFpQkMsY0FBVSxFQUFDLFFBQTVCO0FBQXFDUCxjQUFVLEVBQUMsU0FBaEQ7QUFBMERHLFVBQU0sRUFBQyxDQUFqRTtBQUFtRUUsV0FBTyxFQUFDO0FBQTNFO0FBQTNqQixDQUFiLEM7Ozs7Ozs7Ozs7QUNGMXhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7O0FDTkEsK0Q7Ozs7Ozs7Ozs7O0FDQUEsbUMiLCJmaWxlIjoicGFnZXMvX2Vycm9yLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7dmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ9cmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0XCIpO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuZGVmYXVsdD12b2lkIDA7dmFyIF9yZWFjdD1faW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJyZWFjdFwiKSk7dmFyIF9oZWFkPV9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL25leHQtc2VydmVyL2xpYi9oZWFkXCIpKTtjb25zdCBzdGF0dXNDb2Rlcz17NDAwOidCYWQgUmVxdWVzdCcsNDA0OidUaGlzIHBhZ2UgY291bGQgbm90IGJlIGZvdW5kJyw0MDU6J01ldGhvZCBOb3QgQWxsb3dlZCcsNTAwOidJbnRlcm5hbCBTZXJ2ZXIgRXJyb3InfTtmdW5jdGlvbiBfZ2V0SW5pdGlhbFByb3BzKHtyZXMsZXJyfSl7Y29uc3Qgc3RhdHVzQ29kZT1yZXMmJnJlcy5zdGF0dXNDb2RlP3Jlcy5zdGF0dXNDb2RlOmVycj9lcnIuc3RhdHVzQ29kZTo0MDQ7cmV0dXJue3N0YXR1c0NvZGV9O30vKipcbiAqIGBFcnJvcmAgY29tcG9uZW50IHVzZWQgZm9yIGhhbmRsaW5nIGVycm9ycy5cbiAqL2NsYXNzIEVycm9yIGV4dGVuZHMgX3JlYWN0LmRlZmF1bHQuQ29tcG9uZW50e3JlbmRlcigpe2NvbnN0e3N0YXR1c0NvZGV9PXRoaXMucHJvcHM7Y29uc3QgdGl0bGU9dGhpcy5wcm9wcy50aXRsZXx8c3RhdHVzQ29kZXNbc3RhdHVzQ29kZV18fCdBbiB1bmV4cGVjdGVkIGVycm9yIGhhcyBvY2N1cnJlZCc7cmV0dXJuLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIix7c3R5bGU6c3R5bGVzLmVycm9yfSwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChfaGVhZC5kZWZhdWx0LG51bGwsLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJ0aXRsZVwiLG51bGwsc3RhdHVzQ29kZT9gJHtzdGF0dXNDb2RlfTogJHt0aXRsZX1gOidBcHBsaWNhdGlvbiBlcnJvcjogYSBjbGllbnQtc2lkZSBleGNlcHRpb24gaGFzIG9jY3VycmVkJykpLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsbnVsbCwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIse2Rhbmdlcm91c2x5U2V0SW5uZXJIVE1MOntfX2h0bWw6J2JvZHkgeyBtYXJnaW46IDAgfSd9fSksc3RhdHVzQ29kZT8vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImgxXCIse3N0eWxlOnN0eWxlcy5oMX0sc3RhdHVzQ29kZSk6bnVsbCwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImRpdlwiLHtzdHlsZTpzdHlsZXMuZGVzY30sLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJoMlwiLHtzdHlsZTpzdHlsZXMuaDJ9LHRoaXMucHJvcHMudGl0bGV8fHN0YXR1c0NvZGU/dGl0bGU6LyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoX3JlYWN0LmRlZmF1bHQuRnJhZ21lbnQsbnVsbCxcIkFwcGxpY2F0aW9uIGVycm9yOiBhIGNsaWVudC1zaWRlIGV4Y2VwdGlvbiBoYXMgb2NjdXJyZWQgKFwiLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiYVwiLHtocmVmOlwiaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvY2xpZW50LXNpZGUtZXhjZXB0aW9uLW9jY3VycmVkXCJ9LFwiZGV2ZWxvcGVyIGd1aWRhbmNlXCIpLFwiKVwiKSxcIi5cIikpKSk7fX1leHBvcnRzLmRlZmF1bHQ9RXJyb3I7RXJyb3IuZGlzcGxheU5hbWU9J0Vycm9yUGFnZSc7RXJyb3IuZ2V0SW5pdGlhbFByb3BzPV9nZXRJbml0aWFsUHJvcHM7RXJyb3Iub3JpZ0dldEluaXRpYWxQcm9wcz1fZ2V0SW5pdGlhbFByb3BzO2NvbnN0IHN0eWxlcz17ZXJyb3I6e2NvbG9yOicjMDAwJyxiYWNrZ3JvdW5kOicjZmZmJyxmb250RmFtaWx5OictYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFJvYm90bywgXCJTZWdvZSBVSVwiLCBcIkZpcmEgU2Fuc1wiLCBBdmVuaXIsIFwiSGVsdmV0aWNhIE5ldWVcIiwgXCJMdWNpZGEgR3JhbmRlXCIsIHNhbnMtc2VyaWYnLGhlaWdodDonMTAwdmgnLHRleHRBbGlnbjonY2VudGVyJyxkaXNwbGF5OidmbGV4JyxmbGV4RGlyZWN0aW9uOidjb2x1bW4nLGFsaWduSXRlbXM6J2NlbnRlcicsanVzdGlmeUNvbnRlbnQ6J2NlbnRlcid9LGRlc2M6e2Rpc3BsYXk6J2lubGluZS1ibG9jaycsdGV4dEFsaWduOidsZWZ0JyxsaW5lSGVpZ2h0Oic0OXB4JyxoZWlnaHQ6JzQ5cHgnLHZlcnRpY2FsQWxpZ246J21pZGRsZSd9LGgxOntkaXNwbGF5OidpbmxpbmUtYmxvY2snLGJvcmRlclJpZ2h0OicxcHggc29saWQgcmdiYSgwLCAwLCAwLC4zKScsbWFyZ2luOjAsbWFyZ2luUmlnaHQ6JzIwcHgnLHBhZGRpbmc6JzEwcHggMjNweCAxMHB4IDAnLGZvbnRTaXplOicyNHB4Jyxmb250V2VpZ2h0OjUwMCx2ZXJ0aWNhbEFsaWduOid0b3AnfSxoMjp7Zm9udFNpemU6JzE0cHgnLGZvbnRXZWlnaHQ6J25vcm1hbCcsbGluZUhlaWdodDonaW5oZXJpdCcsbWFyZ2luOjAscGFkZGluZzowfX07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1fZXJyb3IuanMubWFwIiwiZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICBcImRlZmF1bHRcIjogb2JqXG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdDsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL2hlYWQuanNcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOzsiXSwic291cmNlUm9vdCI6IiJ9