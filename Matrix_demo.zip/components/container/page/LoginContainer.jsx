import React, { useState, useEffect } from "react";

import LoginPage from "./LoginPage";

export default function LoginContainer() {
  return <LoginPage />;
}
